﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using GPC.MessageProcessor.Common;
using GPC.MessageProcessor.Common.DTO;
using GPC.MessageProcessor.Data.InlineQuery;

namespace GPC.MessageProcessor.Data
{
    public class MobileRepository : ConnectionFactory, IMobileRepository
    {
        private SqlConnection sqlConnection;

        public MobileRepository()
        {
            sqlConnection = CreateConnection(ConnectionType.Mobile);
        }

        public SqlConnection GetConnection()
        {
            return sqlConnection;
        }

        public void UpdateMobileVisit(SqlTransaction sqlTransaction ,MobileVisit mobileVisit)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, GpcMobileComandText.UpdateMobileVisit, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@QueueNumber", mobileVisit.QueueNumber == null ? DBNull.Value : (object) mobileVisit.QueueNumber));
            sqlCommand.Parameters.Add(new SqlParameter("@VisitStatus", mobileVisit.VisitStatus));
            sqlCommand.Parameters.Add(new SqlParameter("@VisitId", mobileVisit.VisitID));
            sqlCommand.Transaction = sqlTransaction;
            sqlCommand.ExecuteNonQuery();
        }

        public void SendNotification(SqlTransaction sqlTransaction, Notification notification)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, GpcMobileComandText.SendNotification, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@Message", notification.Message));
            sqlCommand.Parameters.Add(new SqlParameter("@PatientProfileFK", notification.PatientProfileFK));
            sqlCommand.Transaction = sqlTransaction;
            sqlCommand.ExecuteNonQuery();
        }

        public void ErrorProcessingMobileVisit(Guid mobileVisitFk)
        {
            SqlConnection mobileSqlConnection = CreateConnection(ConnectionType.Mobile);
            SqlCommand sqlCommand = CreateCommand(mobileSqlConnection, GpcMobileComandText.ErrorProcessingMobileVisit, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@VisitId", mobileVisitFk));
            sqlCommand.Parameters.Add(new SqlParameter("@VisitStatus", MessageQueueStatus.Error));

            mobileSqlConnection.Open();
            sqlCommand.ExecuteNonQuery();
            mobileSqlConnection.Close();
        }
     }
}
