﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using GPC.MessageProcessor.Common;
using GPC.MessageProcessor.Data.InlineQuery;

namespace GPC.MessageProcessor.Data
{
    public class TenantMappingRepository : ConnectionFactory, ITenantMappingRepository
    {
        private SqlConnection sqlConnection;

        public TenantMappingRepository()
        {
            sqlConnection = CreateConnection(ConnectionType.DeskTop);
        }

        public SqlConnection GetConnection()
        {
            return sqlConnection;
        }

        public DataTable GetTenantMappingByTenantCode(string tenantCode)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, GpcMasterCommandText.GetTenantMappingByTenantCode, CommandType.Text);
            SqlParameter sqlParameter = new SqlParameter("@TenantCode", tenantCode);
            sqlCommand.Parameters.Add(sqlParameter);

            sqlConnection.Open();
            DataTable dt = ExecuteCommandDatatable(sqlCommand);
            sqlConnection.Close();

            return dt;
        }
    }
}
