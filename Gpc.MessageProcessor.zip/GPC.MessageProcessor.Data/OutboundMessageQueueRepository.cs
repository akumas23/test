﻿using GPC.MessageProcessor.Common;
using GPC.MessageProcessor.Common.DTO;
using GPC.MessageProcessor.Data.InlineQuery;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace GPC.MessageProcessor.Data
{
    public class OutboundMessageQueueRepository: IOutboundMessageQueueRepository
    {
        private SqlConnection sqlConnection;
        private IConnectionFactory connectionFactory;

        public OutboundMessageQueueRepository(IConnectionFactory connectionFactory)
        {
            this.connectionFactory = connectionFactory;
            sqlConnection = this.connectionFactory.CreateConnection(ConnectionType.OutboundMessage);
        }

        public SqlConnection GetConnection()
        {
            return sqlConnection;
        }

        public DataTable GetOutboundMessageQueueDetailsByID(Guid messageQueueId)
        {
            SqlCommand sqlCommand = connectionFactory.CreateCommand(sqlConnection, GpcOutBoundMessageComandText.GetOutBoundMessageQueueDetailsByID, CommandType.Text);
            SqlParameter sqlParameter = new SqlParameter("@MessageQueueId", messageQueueId);
            sqlCommand.Parameters.Add(sqlParameter);
            return connectionFactory.ExecuteCommandDatatable(sqlCommand);
        }

        public void UpdateOutboundMessageQueueStatus(OutBoundMessageQueue outBoundMessageQueue)
        {
            SqlCommand sqlCommand = connectionFactory.CreateCommand(sqlConnection, GpcOutBoundMessageComandText.UpdateMessageQueueStatus, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@MessageQueueId", outBoundMessageQueue.MessageQueueId));
            sqlCommand.Parameters.Add(new SqlParameter("@ProcessingStatus", outBoundMessageQueue.ProcessingStatus));
            sqlConnection.Open();
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }

        public void LogOutboundMessageProcessing(MessageProcessingLog messageProcessingLog)
        {
            string cmdText = GpcOutBoundMessageComandText.InsertMessageProcessingLog;
            SqlConnection sqlConnection = connectionFactory.CreateConnection(ConnectionType.OutboundMessage);
            SqlCommand sqlCommand = connectionFactory.CreateCommand(sqlConnection, cmdText, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@MessageQueueFK", messageProcessingLog.MessageQueueFK));
            sqlCommand.Parameters.Add(new SqlParameter("@Source", messageProcessingLog.Source));
            sqlCommand.Parameters.Add(new SqlParameter("@LogType", messageProcessingLog.LogType));
            sqlCommand.Parameters.Add(new SqlParameter("@Message", messageProcessingLog.Message));
            sqlCommand.Parameters.Add(new SqlParameter("@LogDate", messageProcessingLog.LogDate));
            sqlConnection.Open();
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }
    }
}
