﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using GPC.MessageProcessor.Common;
using GPC.MessageProcessor.Common.DTO;

namespace GPC.MessageProcessor.Data
{
    public class ConnectionFactory : IConnectionFactory
    {
        private readonly string gpcMobileDBConnectionString;
        private readonly string gpcDesktopDBConnectionString;
        private readonly string gpcOutBoundMessageConnectionString;

        public ConnectionFactory()
        {
            gpcMobileDBConnectionString = ConfigurationManager.AppSettings["GpcMobileDBConnectionString"];
            gpcDesktopDBConnectionString = ConfigurationManager.AppSettings["GpcDesktopDBConnectionString"];
            gpcOutBoundMessageConnectionString = ConfigurationManager.AppSettings["GpcOutBoundMessageConnectionString"];
        }

        public SqlConnection CreateConnection(ConnectionType type)
        {
            SqlConnection sqlConnection = null;
            if (type == ConnectionType.Mobile)
            {
                sqlConnection = new SqlConnection(gpcMobileDBConnectionString);
            }
            else if (type == ConnectionType.DeskTop)
            {
                sqlConnection = new SqlConnection(gpcDesktopDBConnectionString);
            }
            else if (type == ConnectionType.OutboundMessage)
            {
                sqlConnection = new SqlConnection(gpcOutBoundMessageConnectionString);
            }

            return sqlConnection;
        }

        public SqlConnection CreateConnection(TenantMapping tenantMapping)
        {
            string tenantConnectionString = string.Format(ConfigurationManager.AppSettings["GpcTenantDBConnectionString"], tenantMapping.DBServer, tenantMapping.DBName);
            return new SqlConnection(tenantConnectionString);
        }

         public SqlCommand CreateCommand(SqlConnection sqlConnection ,string commandText, CommandType commandType)
        {
            SqlCommand sqlCommand = new SqlCommand(commandText, sqlConnection);
            sqlCommand.CommandType = commandType;
            return sqlCommand;
        }

        public DataTable ExecuteCommandDatatable(SqlCommand sqlCommand)
        {
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataSet ds = new DataSet();
            sqlDataAdapter.Fill(ds);
            return ds.Tables[0];
        }
    }
}
