﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using GPC.MessageProcessor.Common.DTO;
using GPC.MessageProcessor.Data.InlineQuery;
using System.Data;
using GPC.MessageProcessor.Common;

namespace GPC.MessageProcessor.Data
{
    public class TenantRepository: ConnectionFactory, ITenantRepository
    {
        private SqlConnection sqlConnection;
        private TenantCommandText tenantCommandText;

        public void SetTenantConnection(TenantMapping tenantMapping)
        {
            sqlConnection = CreateConnection(tenantMapping);
            tenantCommandText = new TenantCommandText(tenantMapping);
        }

        public SqlConnection GetTenantConnection()
        {
            return sqlConnection;
        }

        public DataTable GetTenantActiveSession(SqlTransaction sqlTransaction)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.GetTenantActiveSession, CommandType.Text);
            sqlCommand.Transaction = sqlTransaction;
            return ExecuteCommandDatatable(sqlCommand);
        }

        public DataTable GetMobileSetting(SqlTransaction sqlTransaction)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.GetMobileSetting, CommandType.Text);
            sqlCommand.Transaction = sqlTransaction;
            return ExecuteCommandDatatable(sqlCommand);
        }

        public DataTable GetClinicDetails(SqlTransaction sqlTransaction)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.GetClinicDetails, CommandType.Text);
            sqlCommand.Transaction = sqlTransaction;
            return ExecuteCommandDatatable(sqlCommand);
        }

        public DataTable GetNewOrExistingPatient(SqlTransaction sqlTransaction, OutBoundMessageQueue outBoundMessageQueue)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.GetExistingPatient, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@PatientAccountNo", outBoundMessageQueue.PatientAccountNo));
            sqlCommand.Parameters.Add(new SqlParameter("@PatientAccountNoTypeFK", outBoundMessageQueue.PatientAccountNoTypeFK));
            sqlCommand.Parameters.Add(new SqlParameter("@DOB", outBoundMessageQueue.DOB));
            sqlCommand.Parameters.Add(new SqlParameter("@Name", outBoundMessageQueue.PatientName));
            sqlCommand.Transaction = sqlTransaction;
            return ExecuteCommandDatatable(sqlCommand);
        }

        public DataTable CreateQueue(SqlTransaction sqlTransaction, Queue queue, MobileBooking mobileBooking)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.CreateQueue, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@QueueNo", queue.QueueNo));
            sqlCommand.Parameters.Add(new SqlParameter("@QueueNoPrefix", queue.QueueNoPrefix));
            sqlCommand.Parameters.Add(new SqlParameter("@MobileBookingFK", mobileBooking.MobileBookingID));
            sqlCommand.Parameters.Add(new SqlParameter("@CreateByLoginFK", queue.CreateByLoginFK));
            sqlCommand.Parameters.Add(new SqlParameter("@CreateByUserFK", queue.CreateByUserFK));
            sqlCommand.Parameters.Add(new SqlParameter("@CreateByClinicFK", queue.CreateByClinicFK));
            sqlCommand.Parameters.Add(new SqlParameter("@UpdateByLoginFK", queue.UpdateByLoginFK));
            sqlCommand.Parameters.Add(new SqlParameter("@UpdateByUserFK", queue.UpdateByUserFK));
            sqlCommand.Parameters.Add(new SqlParameter("@UpdateByClinicFK", queue.UpdateByClinicFK));
            sqlCommand.Transaction = sqlTransaction;
            return ExecuteCommandDatatable(sqlCommand);
        }

        public void UpdateMobileVisitBooking(SqlTransaction sqlTransaction, MobileBooking mobileBooking)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.UpdateMobileVisitBooking, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@MobileBookingID", mobileBooking.MobileBookingID));
            sqlCommand.Parameters.Add(new SqlParameter("@Remarks", mobileBooking.BookingStatusRemarks.Remarks == null ? DBNull.Value : (object)mobileBooking.BookingStatusRemarks.Remarks));
            sqlCommand.Parameters.Add(new SqlParameter("@BookingStatus", mobileBooking.BookingStatusRemarks.BookingStatus));
            sqlCommand.Parameters.Add(new SqlParameter("@BookingDate", mobileBooking.BookingDate));
            sqlCommand.Parameters.Add(new SqlParameter("@BookingRemarks", mobileBooking.BookingRemarks));
            sqlCommand.Parameters.Add(new SqlParameter("@MobileVisitDate", mobileBooking.MobileVisitDate));
            sqlCommand.Parameters.Add(new SqlParameter("@UpdateByMobilePatientFK", mobileBooking.UpdateByMobilePatientFK));
            sqlCommand.Parameters.Add(new SqlParameter("@QueueSetupFK", mobileBooking.QueueSetupFK == null ? DBNull.Value : (object)mobileBooking.QueueSetupFK));
            sqlCommand.Transaction = sqlTransaction;
            sqlCommand.ExecuteNonQuery();
        }

        public DataTable CreateMobileVisitBooking(SqlTransaction sqlTransaction, MobileBooking mobileBooking)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.CreateMobileVisitBooking, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@BizSessionFK", mobileBooking.BizSessionFK == null ? DBNull.Value : (object) mobileBooking.BizSessionFK));
            sqlCommand.Parameters.Add(new SqlParameter("@PatientName", mobileBooking.PatientName));
            sqlCommand.Parameters.Add(new SqlParameter("@PatientAccountNoTypeFK", mobileBooking.PatientAccountNoTypeFK));
            sqlCommand.Parameters.Add(new SqlParameter("@PatientAccountNo", mobileBooking.PatientAccountNo));
            sqlCommand.Parameters.Add(new SqlParameter("@GenderFK", mobileBooking.GenderFK));
            sqlCommand.Parameters.Add(new SqlParameter("@DOB", mobileBooking.DOB));
            sqlCommand.Parameters.Add(new SqlParameter("@Number", mobileBooking.Number == null ? DBNull.Value : (object) mobileBooking.Number));
            sqlCommand.Parameters.Add(new SqlParameter("@PatientType", mobileBooking.PatientType));
            sqlCommand.Parameters.Add(new SqlParameter("@DesktopPatientProfileFK", mobileBooking.DesktopPatientProfileFK == null ? DBNull.Value : (object) mobileBooking.DesktopPatientProfileFK));
            sqlCommand.Parameters.Add(new SqlParameter("@MobileVisitFK", mobileBooking.MobileVisitFK));
            sqlCommand.Parameters.Add(new SqlParameter("@MobileVisitDate", mobileBooking.MobileVisitDate));
            sqlCommand.Parameters.Add(new SqlParameter("@BookingDate", mobileBooking.BookingDate));
            sqlCommand.Parameters.Add(new SqlParameter("@BookingStatus", mobileBooking.BookingStatusRemarks.BookingStatus));
            sqlCommand.Parameters.Add(new SqlParameter("@BookingRemarks", mobileBooking.BookingRemarks));
            sqlCommand.Parameters.Add(new SqlParameter("@Remarks", mobileBooking.BookingStatusRemarks.Remarks == null ? DBNull.Value : (object) mobileBooking.BookingStatusRemarks.Remarks));
            sqlCommand.Parameters.Add(new SqlParameter("@CreateByMobilePatientFK", mobileBooking.CreateByMobilePatientFK));
            sqlCommand.Parameters.Add(new SqlParameter("@UpdateByMobilePatientFK", mobileBooking.UpdateByMobilePatientFK));
            sqlCommand.Parameters.Add(new SqlParameter("@QueueSetupFK", mobileBooking.QueueSetupFK == null ? DBNull.Value : (object)mobileBooking.QueueSetupFK));
            sqlCommand.Transaction = sqlTransaction;
            return ExecuteCommandDatatable(sqlCommand);
        }

        public DataTable GetQueueNoByBizSessionID(SqlTransaction sqlTransaction, Guid bizSessionID)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.GetQueueNoByBizSessionID, CommandType.StoredProcedure);
            sqlCommand.Parameters.Add(new SqlParameter("@BizSessionID", bizSessionID));
            sqlCommand.Transaction = sqlTransaction;
            return ExecuteCommandDatatable(sqlCommand);
        }

        public DataTable GetCurrentVisitBookingCount(SqlTransaction sqlTransaction)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.GetCurrentVisitBookingCount, CommandType.Text);
            sqlCommand.Transaction = sqlTransaction;
            return ExecuteCommandDatatable(sqlCommand);
        }

        public DataTable GetMobileBookingByMobileVisitFK(SqlTransaction sqlTransaction, Guid MobileVisitFK)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.GetMobileBookingByMobileVisitFK, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@MobileVisitFK", MobileVisitFK));
            sqlCommand.Transaction = sqlTransaction;
            return ExecuteCommandDatatable(sqlCommand);
        }

        public void UpdateQueue(SqlTransaction sqlTransaction, Queue queue)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.UpdateQueue, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("QueueID", queue.QueueID));
            sqlCommand.Parameters.Add(new SqlParameter("@QueueNo", queue.QueueNo));
            sqlCommand.Parameters.Add(new SqlParameter("@QueueNoPrefix", queue.QueueNoPrefix));
            sqlCommand.Parameters.Add(new SqlParameter("@UpdateByLoginFK", DefaultAuditFieldsGuid.Login));
            sqlCommand.Parameters.Add(new SqlParameter("@UpdateByUserFK", DefaultAuditFieldsGuid.User));
            sqlCommand.Transaction = sqlTransaction;
            sqlCommand.ExecuteNonQuery();
        }

        public DataTable GetCurrentQueueByMobileBookingFK(SqlTransaction sqlTransaction, Guid MobileBookingFK)
        {
            SqlCommand sqlCommand = CreateCommand(sqlConnection, tenantCommandText.GetCurrentQueueByMobileBookingFK, CommandType.Text);
            sqlCommand.Parameters.Add(new SqlParameter("@MobileBookingFK", MobileBookingFK));
            sqlCommand.Transaction = sqlTransaction;
            return ExecuteCommandDatatable(sqlCommand);
        }
    }
}
