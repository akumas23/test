﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using GPC.MessageProcessor.Common;
using GPC.MessageProcessor.Common.DTO;

namespace GPC.MessageProcessor.Data
{
    public interface IConnectionFactory
    {
        SqlConnection CreateConnection(ConnectionType type);
        SqlCommand CreateCommand(SqlConnection sqlConnection, string commandText, CommandType commandType);
        DataTable ExecuteCommandDatatable(SqlCommand sqlCommand);
        SqlConnection CreateConnection(TenantMapping tenantMapping);
    }
}
