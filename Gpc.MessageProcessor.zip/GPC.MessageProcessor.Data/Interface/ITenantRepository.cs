﻿using System;
using System.Collections.Generic;
using System.Text;
using GPC.MessageProcessor.Common.DTO;
using System.Data.SqlClient;
using System.Data;

namespace GPC.MessageProcessor.Data
{
    public interface ITenantRepository
    {
        void SetTenantConnection(TenantMapping tenantMapping);
        SqlConnection GetTenantConnection();
        DataTable GetTenantActiveSession(SqlTransaction sqlTransaction);
        DataTable GetNewOrExistingPatient(SqlTransaction sqlTransaction, OutBoundMessageQueue outBoundMessageQueue);
        DataTable CreateMobileVisitBooking(SqlTransaction sqlTransaction, MobileBooking mobileBooking);
        DataTable GetQueueNoByBizSessionID(SqlTransaction sqlTransaction, Guid bizSessionID);
        DataTable CreateQueue(SqlTransaction sqlTransaction, Queue queue, MobileBooking mobileBooking);
        DataTable GetMobileSetting(SqlTransaction sqlTransaction);
        DataTable GetCurrentVisitBookingCount(SqlTransaction sqlTransaction);
        DataTable GetMobileBookingByMobileVisitFK(SqlTransaction sqlTransaction, Guid MobileVisitFK);
        DataTable GetCurrentQueueByMobileBookingFK(SqlTransaction sqlTransaction, Guid MobileBookingFK);
        void UpdateMobileVisitBooking(SqlTransaction sqlTransaction, MobileBooking mobileBooking);
        void UpdateQueue(SqlTransaction sqlTransaction, Queue queue);
        DataTable GetClinicDetails(SqlTransaction sqlTransaction);
    }
}
