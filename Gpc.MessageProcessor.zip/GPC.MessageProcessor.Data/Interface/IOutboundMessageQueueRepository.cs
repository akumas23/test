﻿using GPC.MessageProcessor.Common.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace GPC.MessageProcessor.Data
{
    public interface IOutboundMessageQueueRepository
    {
        void LogOutboundMessageProcessing(MessageProcessingLog messageProcessingLog);
        DataTable GetOutboundMessageQueueDetailsByID(Guid messageQueueId);
        void UpdateOutboundMessageQueueStatus(OutBoundMessageQueue outBoundMessageQueue);
        SqlConnection GetConnection();
    }
}
