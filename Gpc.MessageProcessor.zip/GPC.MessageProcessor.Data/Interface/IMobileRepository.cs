﻿using GPC.MessageProcessor.Common.DTO;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace GPC.MessageProcessor.Data
{
    public interface IMobileRepository
    {
        void UpdateMobileVisit(SqlTransaction sqlTransaction, MobileVisit mobileVisit);
        SqlConnection GetConnection();
        void ErrorProcessingMobileVisit(Guid mobileVisitFk);
        void SendNotification(SqlTransaction sqlTransaction, Notification notification);
    }
}
