﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace GPC.MessageProcessor.Data
{
    public interface ITenantMappingRepository
    {
        DataTable GetTenantMappingByTenantCode(string tenantCode);
    }
}
