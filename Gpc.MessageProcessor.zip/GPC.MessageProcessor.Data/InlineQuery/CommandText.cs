﻿using System;
using System.Collections.Generic;
using System.Text;
using GPC.MessageProcessor.Common.DTO;

namespace GPC.MessageProcessor.Data.InlineQuery
{
    

    public static class GpcOutBoundMessageComandText
    {
        public static string GetOutBoundMessageQueueDetailsByID = "SELECT * FROM OutBoundMessageQueue WHERE MessageQueueId = @MessageQueueId";
        public static string UpdateMessageQueueStatus = "UPDATE OutBoundMessageQueue SET ProcessingStatus = @ProcessingStatus WHERE MessageQueueId = @MessageQueueId";
        public static string InsertMessageProcessingLog = "INSERT INTO MessageProcessingLog(MessageQueueFK,Source,LogType,[Message], LogDate) VALUES(@MessageQueueFK,@Source,@LogType,@Message,@LogDate)";
    }

    public static class GpcMobileComandText
    {
        public static string UpdateMobileVisit = "UPDATE Visit.Visit SET QueueNumber = @QueueNumber, VisitStatus = @VisitStatus WHERE VisitId = @VisitId";
        public static string ErrorProcessingMobileVisit = "UPDATE Visit.Visit SET VisitStatus = @VisitStatus WHERE VisitId = @VisitId";
        public static string SendNotification
        {
            get
            {
                StringBuilder query = new StringBuilder("INSERT INTO[Notification].[Notification] ");
                query.AppendLine("(NotificationID, Message, PatientProfileFK, CreateDate, IsRead)");
                query.AppendLine("VALUES(NEWID(), @Message, @PatientProfileFK, GETDATE(),0)");
                return query.ToString();
            }
        }
    }

    public static class GpcMasterCommandText
    {
        public static string GetTenantMappingByTenantCode = "SELECT * FROM GPCMaster.TenantMapping where TenantCode = @TenantCode";
    }

    public class TenantCommandText
    {
        private static string TenantSchema;
        public TenantCommandText(TenantMapping tenantMapping)
        {
            TenantSchema = tenantMapping.SchemaName;
        }

        #region Tenant Command
        public string GetTenantActiveSession
        {
            get { return string.Format("SELECT TOP 1 BizSessionID FROM {0}.BizSession WHERE IsClinicSessionClosed = 0", TenantSchema); }
        }

        public string GetMobileSetting
        {
            get { return string.Format("SELECT TOP 1 * FROM {0}.MobileSetting", TenantSchema); }
        }

        public string GetClinicDetails
        {
            get { return string.Format("SELECT TOP 1 * FROM {0}.Clinic ORDER BY IsPrimary DESC", TenantSchema); }
        }

        public string GetExistingPatient
        {
            get
            {
                StringBuilder query = new StringBuilder("SELECT PatientProfileID, PatientAccountNoTypeFK, PatientAccountNo, Name, GenderFK, DOB ");
                query.AppendLine("FROM {0}.PatientProfile p");
                query.AppendLine("WHERE PatientAccountNo = @PatientAccountNo AND PatientAccountNoTypeFK = @PatientAccountNoTypeFK AND Name = @Name AND DOB = @DOB ORDER BY IsDeleted DESC");
                return string.Format(query.ToString(), TenantSchema);
            }
        }

        public string CreateQueue
        {
            get
            {
                StringBuilder query = new StringBuilder("DECLARE @QueueID UNIQUEIDENTIFIER; ");
                query.AppendLine("SET @QueueID = NEWID();");
                query.AppendLine("INSERT INTO {0}.Queue(QueueID, QueueNo, QueueNoPrefix, IsDeleted, MobileBookingFK,");
                query.AppendLine("CreateDate, CreateByLoginFK, CreateByUserFK, CreateByClinicFK,");
                query.AppendLine("UpdateDate, UpdateByLoginFK, UpdateByUserFK, UpdateByClinicFK)");
                query.AppendLine("VALUES(@QueueID, @QueueNo, @QueueNoPrefix, 0, @MobileBookingFK,");
                query.AppendLine("GETDATE(), @CreateByLoginFK, @CreateByUserFK, @CreateByClinicFK,");
                query.AppendLine("GETDATE(), @UpdateByLoginFK, @UpdateByUserFK, @UpdateByClinicFK);");
                query.AppendLine("SELECT @QueueID");
                return string.Format(query.ToString(), TenantSchema);
            }
        }

        public string UpdateMobileVisitBooking
        {
            get
            {
                StringBuilder query = new StringBuilder("UPDATE {0}.MobileBooking ");
                query.AppendLine("SET Remarks = @Remarks,BookingStatus = @BookingStatus,BookingDate = @BookingDate,BookingRemarks = @BookingRemarks,MobileVisitDate = @MobileVisitDate,QueueSetupFK = @QueueSetupFK,");
                query.AppendLine("UpdateByMobilePatientFK = @UpdateByMobilePatientFK,");
                query.AppendLine("UpdateDate = GETDATE()");
                query.AppendLine("WHERE MobileBookingID = @MobileBookingID");
                return string.Format(query.ToString(), TenantSchema);
            }
        }

        public string CreateMobileVisitBooking
        {
            get
            {
                StringBuilder query = new StringBuilder("DECLARE @MobileBookingID UNIQUEIDENTIFIER; ");
                query.AppendLine("SET @MobileBookingID = NEWID();");
                query.AppendLine("INSERT INTO {0}.MobileBooking(MobileBookingID, BizSessionFK,");
                query.AppendLine("PatientName, PatientAccountNoTypeFK, PatientAccountNo, GenderFK, DOB, Number, PatientType, DesktopPatientProfileFK,");
                query.AppendLine("MobileVisitFK, MobileVisitDate,");
                query.AppendLine("BookingDate, BookingStatus, BookingRemarks, Remarks,");
                query.AppendLine("CreateDate, CreateByMobilePatientFK, UpdateDate, UpdateByMobilePatientFK, QueueSetupFK)");
                query.AppendLine("VALUES(@MobileBookingID, @BizSessionFK,");
                query.AppendLine("@PatientName, @PatientAccountNoTypeFK, @PatientAccountNo, @GenderFK, @DOB, @Number, @PatientType, @DesktopPatientProfileFK,");
                query.AppendLine("@MobileVisitFK, @MobileVisitDate,");
                query.AppendLine("@BookingDate, @BookingStatus, @BookingRemarks, @Remarks,");
                query.AppendLine("GETDATE(), @CreateByMobilePatientFK, GETDATE(), @UpdateByMobilePatientFK, @QueueSetupFK)");
                query.AppendLine("SELECT @MobileBookingID");
                return string.Format(query.ToString(), TenantSchema);
            }
        }

        public string GetQueueNoByBizSessionID
        {
            get
            {
                StringBuilder query = new StringBuilder("{0}.GET_QueueManagement_BiggestQueueNo_ByBizSessionID");
                return string.Format(query.ToString(), TenantSchema);
            }
        }

        public string GetCurrentVisitBookingCount
        {
            get
            {
                StringBuilder query = new StringBuilder("SELECT COUNT(1) FROM {0}.MobileBooking ");
                query.AppendLine("WHERE FLOOR(CAST(MobileVisitDate AS FLOAT)) = FLOOR(CAST(GETDATE() AS FLOAT))");
                query.AppendLine("AND MobileVisitFK IS NOT NULL");
                query.AppendLine("AND BookingStatus in ('Confirmed', 'Actualised', 'Requeued', 'Missed')");
                return string.Format(query.ToString(), TenantSchema);
            }
        }

        public string GetMobileBookingByMobileVisitFK
        {
            get
            {
                StringBuilder query = new StringBuilder("SELECT * FROM {0}.MobileBooking WHERE MobileVisitFK = @MobileVisitFK ");
                return string.Format(query.ToString(), TenantSchema);
            }
        }

        public string UpdateQueue
        {
            get
            {
                StringBuilder query = new StringBuilder("UPDATE {0}.Queue ");
                query.AppendLine("SET QueueNo = @QueueNo,");
                query.AppendLine("QueueNoPrefix = @QueueNoPrefix,");
                query.AppendLine("UpdateDate = GETDATE(),");
                query.AppendLine("UpdateByLoginFK = @UpdateByLoginFK,");
                query.AppendLine("UpdateByUserFK = @UpdateByUserFK");
                query.AppendLine("WHERE QueueID = @QueueID");
                return string.Format(query.ToString(), TenantSchema);
            }
        }

        public string GetCurrentQueueByMobileBookingFK
        {
            get
            {
                StringBuilder query = new StringBuilder("SELECT * FROM {0}.Queue WHERE MobileBookingFK = @MobileBookingFK ");
                return string.Format(query.ToString(), TenantSchema);
            }
        }
        #endregion
    }
}
