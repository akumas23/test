﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using GPC.MessageProcessor.Common.DTO;
using System.Data;

namespace GPC.MessageProcessor.QueueProcessor
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {
            this.CreateMap<DataRow, OutBoundMessageQueue>()
                .ForMember(o => o.MessageQueueId, d => d.MapFrom(s => s["MessageQueueId"]))
                .ForMember(o => o.TenantCode, d => d.MapFrom(s => s["TenantCode"]))
                .ForMember(o => o.PatientProfileId, d => d.MapFrom(s => s["PatientProfileId"]))
                .ForMember(o => o.PatientName, d => d.MapFrom(s => s["PatientName"]))
                .ForMember(o => o.PatientAccountNoTypeFK, d => d.MapFrom(s => s["PatientAccountNoTypeFK"]))
                .ForMember(o => o.PatientAccountNo, d => d.MapFrom(s => s["PatientAccountNo"]))
                .ForMember(o => o.GenderFK, d => d.MapFrom(s => s["GenderFK"]))
                .ForMember(o => o.DOB, d => d.MapFrom(s => s["DOB"]))
                .ForMember(o => o.Number, d => d.MapFrom(s => s.IsNull("Number") ? null : s["Number"]))
                .ForMember(o => o.VisitId, d => d.MapFrom(s => s.IsNull("VisitId") ? null : s["VisitId"]))
                .ForMember(o => o.VisitDate, d => d.MapFrom(s => s.IsNull("VisitDate") ? null : s["VisitDate"]))
                .ForMember(o => o.AppointmentId, d => d.MapFrom(s => s.IsNull("AppointmentId") ? null: s["AppointmentId"]))
                .ForMember(o => o.AppointmentDate, d => d.MapFrom(s => s.IsNull("AppointmentDate") ? null: s["AppointmentDate"]))
                .ForMember(o => o.DoctorFK, d => d.MapFrom(s => s.IsNull("DoctorFK") ? null : s["DoctorFK"]))
                .ForMember(o => o.BookingRemarks, d => d.MapFrom(s => s["BookingRemarks"]))
                .ForMember(o => o.BookingDate, d => d.MapFrom(s => s["BookingDate"]))
                .ForMember(o => o.TransactionType, d => d.MapFrom(s => s["TransactionType"]))
                .ForMember(o => o.CreateDate, d => d.MapFrom(s => s["CreateDate"]))
                .ForMember(o => o.CreateByPatientProfileId, d => d.MapFrom(s => s["CreateByPatientProfileId"]))
                .ForMember(o => o.ProcessingStatus, d => d.MapFrom(s => s["ProcessingStatus"]));

            this.CreateMap<DataRow, TenantMapping>()
               .ForMember(o => o.TenantID, d => d.MapFrom(s => s["TenantID"]))
               .ForMember(o => o.TenantCode, d => d.MapFrom(s => s["TenantCode"]))
               .ForMember(o => o.SchemaName, d => d.MapFrom(s => s["SchemaName"]))
               .ForMember(o => o.DBServer, d => d.MapFrom(s => s["DBServer"]))
               .ForMember(o => o.DBName, d => d.MapFrom(s => s["DBName"]))
               .ForMember(o => o.HospitalCode, d => d.MapFrom(s => s["HospitalCode"]))
               .ForMember(o => o.HeCode, d => d.MapFrom(s => s["HeCode"]));

            this.CreateMap<DataRow, PatientProfile>()
               .ForMember(o => o.PatientProfileID, d => d.MapFrom(s => s.IsNull("PatientProfileID") ? null : s["PatientProfileID"]))
               .ForMember(o => o.PatientAccountNoTypeFK, d => d.MapFrom(s => s.IsNull("PatientAccountNoTypeFK") ? null : s["PatientAccountNoTypeFK"]))
               .ForMember(o => o.PatientAccountNo, d => d.MapFrom(s => s["PatientAccountNo"]))
               .ForMember(o => o.Name, d => d.MapFrom(s => s["Name"]))
               .ForMember(o => o.GenderFK, d => d.MapFrom(s => s.IsNull("GenderFK") ? null : s["GenderFK"]))
               .ForMember(o => o.DOB, d => d.MapFrom(s => s.IsNull("DOB")? null : s["DOB"]));

            this.CreateMap<OutBoundMessageQueue, PatientProfile>()
                .ForMember(o => o.PatientProfileID, s => s.Ignore())
                .ForMember(o => o.Name, d => d.MapFrom(s => s.PatientName));

            this.CreateMap<DataRow, MobileSetting>()
               .ForMember(o => o.MobileSettingID, d => d.MapFrom(s => s["MobileSettingID"]))
               .ForMember(o => o.IsMobileSettingsEnabled, d => d.MapFrom(s => s["IsMobileSettingsEnabled"]))
               .ForMember(o => o.IsAllowVisitBookingEnabled, d => d.MapFrom(s => s["IsAllowVisitBookingEnabled"]))
               .ForMember(o => o.AllowedVisitBooking, d => d.MapFrom(s => s["AllowedVisitBooking"]))
               .ForMember(o => o.IsVisitMaxCapEnabled, d => d.MapFrom(s => s["IsVisitMaxCapEnabled"]))
               .ForMember(o => o.VisitMaxCap, d => d.MapFrom(s => s["VisitMaxCap"]))
               .ForMember(o => o.VisitPushNotification, d => d.MapFrom(s => s["VisitPushNotification"]))
               .ForMember(o => o.IsAutomateMissedQueueEnabled, d => d.MapFrom(s => s["IsAutomateMissedQueueEnabled"]))
               .ForMember(o => o.IsAllowAppointmentBookingEnabled, d => d.MapFrom(s => s["IsAllowAppointmentBookingEnabled"]))
               .ForMember(o => o.AllowedAppointmentBooking, d => d.MapFrom(s => s["AllowedAppointmentBooking"]))
               .ForMember(o => o.IsShowServiceStationEnabled, d => d.MapFrom(s => s["IsShowServiceStationEnabled"]))
               .ForMember(o => o.IsShowClinicianNamesEnabled, d => d.MapFrom(s => s["IsShowClinicianNamesEnabled"]))
               .ForMember(o => o.AppointmentDuration, d => d.MapFrom(s => s["AppointmentDuration"]))
               .ForMember(o => o.IsAppointmentMaxCapEnabled, d => d.MapFrom(s => s["IsAppointmentMaxCapEnabled"]))
               .ForMember(o => o.AppointmentMaxCap, d => d.MapFrom(s => s["AppointmentMaxCap"]))
               .ForMember(o => o.AppointmentPushNotification, d => d.MapFrom(s => s["AppointmentPushNotification"]))
               .ForMember(o => o.IsShowNumberOfWaitingPatientsEnabled, d => d.MapFrom(s => s["IsShowNumberOfWaitingPatientsEnabled"]))
               .ForMember(o => o.IsShowApproximateWaitingTimeEnabled, d => d.MapFrom(s => s["IsShowApproximateWaitingTimeEnabled"]))
               .ForMember(o => o.ApproximateWaitingTime, d => d.MapFrom(s => s["ApproximateWaitingTime"]));

            this.CreateMap<DataRow, MobileBooking>()
                .ForMember(o => o.MobileBookingID, d => d.MapFrom(s => s["MobileBookingID"]))
                .ForMember(o => o.BizSessionFK, d => d.MapFrom(s => s["BizSessionFK"]))
                .ForMember(o => o.PatientName, d => d.MapFrom(s => s["PatientName"]))
                .ForMember(o => o.PatientAccountNoTypeFK, d => d.MapFrom(s => s["PatientAccountNoTypeFK"]))
                .ForMember(o => o.PatientAccountNo, d => d.MapFrom(s => s["PatientAccountNo"]))
                .ForMember(o => o.GenderFK, d => d.MapFrom(s => s["GenderFK"]))
                .ForMember(o => o.DOB, d => d.MapFrom(s => s["DOB"]))
                .ForMember(o => o.Number, d => d.MapFrom(s => s["Number"]))
                .ForMember(o => o.PatientType, d => d.MapFrom(s => s["PatientType"]))
                .ForMember(o => o.DesktopPatientProfileFK, d => d.MapFrom(s => s["DesktopPatientProfileFK"]))
                .ForMember(o => o.MobileVisitFK, d => d.MapFrom(s => s["MobileVisitFK"]))
                .ForMember(o => o.MobileVisitDate, d => d.MapFrom(s => s["MobileVisitDate"]))
                .ForPath(o => o.BookingStatusRemarks.BookingStatus, d => d.MapFrom(s => s["BookingStatus"]))
                .ForPath(o => o.BookingStatusRemarks.Remarks, d => d.MapFrom(s => s["Remarks"]))
                .ForMember(o => o.BookingDate, d => d.MapFrom(s => s["BookingDate"]))
                .ForMember(o => o.BookingRemarks, d => d.MapFrom(s => s["BookingRemarks"]))
                .ForMember(o => o.CreateByMobilePatientFK, d => d.MapFrom(s => s["CreateByMobilePatientFK"]))
                .ForMember(o => o.UpdateByMobilePatientFK, d => d.MapFrom(s => s["UpdateByMobilePatientFK"]));

            this.CreateMap<DataRow, Queue>()
                .ForMember(o => o.QueueID, d => d.MapFrom(s => s["QueueID"]))
                .ForMember(o => o.QueueNo, d => d.MapFrom(s => s["QueueNo"]))
                .ForMember(o => o.QueueNoPrefix, d => d.MapFrom(s => s["QueueNoPrefix"]))
                .ForMember(o => o.VisitFK, d => d.MapFrom(s => s.IsNull("VisitFK") ? null : s["VisitFK"]))
                .ForMember(o => o.IsDeleted, d => d.MapFrom(s => s["IsDeleted"]))
                .ForMember(o => o.CreateDate, d => d.MapFrom(s => s["CreateDate"]))
                .ForMember(o => o.CreateByLoginFK, d => d.MapFrom(s => s["CreateByLoginFK"]))
                .ForMember(o => o.CreateByUserFK, d => d.MapFrom(s => s["CreateByUserFK"]))
                .ForMember(o => o.CreateByClinicFK, d => d.MapFrom(s => s["CreateByClinicFK"]))
                .ForMember(o => o.UpdateDate, d => d.MapFrom(s => s["UpdateDate"]))
                .ForMember(o => o.UpdateByLoginFK, d => d.MapFrom(s => s["UpdateByLoginFK"]))
                .ForMember(o => o.UpdateByUserFK, d => d.MapFrom(s => s["UpdateByUserFK"]))
                .ForMember(o => o.UpdateByClinicFK, d => d.MapFrom(s => s["UpdateByClinicFK"]))
                .ForMember(o => o.MobileBookingFK, d => d.MapFrom(s => s.IsNull("MobileBookingFK") ? null : s["MobileBookingFK"]));

            this.CreateMap<DataRow, Clinic>()
                .ForMember(o => o.ClinicID, d => d.MapFrom(s => s["ClinicID"]))
                .ForMember(o => o.ClinicName, d => d.MapFrom(s => s["ClinicName"]))
                .ForMember(o => o.ClinicCode, d => d.MapFrom(s => s["ClinicCode"]));
        }
    }
}
