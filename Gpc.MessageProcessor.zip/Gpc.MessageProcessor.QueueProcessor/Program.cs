﻿using System;
using GPC.MessageProcessor.Service;
using GPC.MessageProcessor.Data;
using Microsoft.Extensions.DependencyInjection;
using AutoMapper;
using GPC.MessageProcessor.Common;
using GPC.MessageProcessor.Common.DTO;
using System.Collections.Generic;

namespace GPC.MessageProcessor.QueueProcessor
{
    static class Program
    {
        private static IMobileService mobileService;
        private static ITenantMappingService tenantMappingService;
        private static ITenantService tenantService;
        private static IOutboundMessageQueueService outboundMessageQueueService;
        private static Guid messageQueueId;
        private static OutBoundMessageQueue outBoundMessageQueue;

        static void Main(string[] args)
        {
            //Generic error handler
            System.AppDomain.CurrentDomain.UnhandledException += UnhandledExceptionLogger;

            //Configure services
            ServiceConfiguration sc = new ServiceConfiguration();
            sc.ConfigureServices(out mobileService, out tenantMappingService, out outboundMessageQueueService, out tenantService);

            //Get outbound message to process
            //messageQueueId = new Guid(args[0]);
            messageQueueId = new Guid("1F640355-C56B-4519-ADE5-F14593DE68E6");
            outBoundMessageQueue = outboundMessageQueueService.GetOutBoundMessageQueueDetailsByID(messageQueueId);

            //Update message status to inprogress
            outboundMessageQueueService.LogMessage("Set Outboundmessage status to inprogress");
            outBoundMessageQueue.ProcessingStatus = MessageQueueStatus.InProgress;
            outboundMessageQueueService.UpdateMessageQueueStatus(outBoundMessageQueue);

            //Get Tenant mapping
            outboundMessageQueueService.LogMessage("Getting tenant mapping");
            TenantMapping tenantMapping = tenantMappingService.GetTenantMappingByTenantCode(outBoundMessageQueue.TenantCode);

            //Set Tenant Connection and OutBoundMessage to Process
            tenantService.ConfigureTenantTransactionService(tenantMapping, outBoundMessageQueue);

            //Get Mobile setting
            outboundMessageQueueService.LogMessage("Getting tenant mobile settings");
            tenantService.GetMobileSetting();

            //Process MessageQueueRequest
            ProcessMessageQueueRequest();

            //Update message status to Completed
            outboundMessageQueueService.LogMessage("Set Outboundmessage status to completed");
            outBoundMessageQueue.ProcessingStatus = MessageQueueStatus.Completed;
            outboundMessageQueueService.UpdateMessageQueueStatus(outBoundMessageQueue);
        }

        private static void ProcessMessageQueueRequest()
        {
            try
            {
                outboundMessageQueueService.LogMessage("Begin DB transaction");
                tenantService.StartTransaction("MessageBookingTransaction");
                mobileService.StartTransaction("MessageBookingTransaction");

                //Check if new/existing patient
                tenantService.GetNewOrExistingPatient();

                if (outBoundMessageQueue.VisitId != null)
                {
                    ProcessVisistBooking();
                }

                outboundMessageQueueService.LogMessage("Commit DB transaction");
                tenantService.CommitTransaction();
                mobileService.CommitTransaction();
            }
            catch (Exception ex)
            {
                outboundMessageQueueService.LogMessage("Rollback DB transaction");
                tenantService.RollBackTransaction();
                mobileService.RollBackTransaction();
                outBoundMessageQueue.ProcessingStatus = MessageQueueStatus.Error;
                outboundMessageQueueService.UpdateMessageQueueStatus(outBoundMessageQueue);
                mobileService.ErrorProcessingMobileVisit((Guid) outBoundMessageQueue.VisitId);
                throw new Exception(ex.Message + " - " +ex.StackTrace, ex.InnerException);
            }
            finally
            {
                tenantService.CleanUpConnection();
            }
        }

        private static void ProcessVisistBooking()
        {
            MobileVisit mobileVisit;
            BookingStatusRemarks bookingStatusRemarks = new BookingStatusRemarks();
            Guid? BizSessionID;
            VisitBookingProcessor visitBookingProcessor;

            //Get active session for visit booking
            outboundMessageQueueService.LogMessage("Get tenant active session");
            BizSessionID = tenantService.GetTenantActiveSession();
            if (BizSessionID == null)
            {
                bookingStatusRemarks.BookingStatus = BookingStatus.Rejected;
                bookingStatusRemarks.Remarks = BookingMessage.NoActiveBizSession;
            }
            else
            {
                bookingStatusRemarks.BookingStatus = BookingStatus.Confirmed;
                bookingStatusRemarks.Remarks = null;
            }

            visitBookingProcessor = new VisitBookingProcessor(tenantService, BizSessionID, outboundMessageQueueService);

            mobileVisit = new MobileVisit()
            {
                VisitID = (Guid)outBoundMessageQueue.VisitId,
                VisitStatus = bookingStatusRemarks.BookingStatus
            };

            if (outBoundMessageQueue.TransactionType == TransactionType.New)
            {
                visitBookingProcessor.ProcessNewVisitBooking(bookingStatusRemarks, mobileVisit);
            }
            else if (outBoundMessageQueue.TransactionType == TransactionType.Requeue)
            {
                visitBookingProcessor.ProcessRequeueVisitBooking(bookingStatusRemarks, mobileVisit, outBoundMessageQueue);
            }
            else if (outBoundMessageQueue.TransactionType == TransactionType.Cancel)
            {
                visitBookingProcessor.ProcessCancelVisitBooking(mobileVisit, outBoundMessageQueue);
            }

            mobileService.UpdateMobileVisit(mobileVisit);

            outboundMessageQueueService.LogMessage("Get clinic details");
            Clinic clinic = tenantService.GetClinicDetails();

            outboundMessageQueueService.LogMessage("Send notification");
            mobileService.SendVisitNotification(mobileVisit, outBoundMessageQueue, clinic);
        }

        static void UnhandledExceptionLogger(object sender, UnhandledExceptionEventArgs ex)
        {
            string errorMessage = ex.ExceptionObject.ToString();
            outboundMessageQueueService.LogMessage(errorMessage, MessageProcessingLogType.ERROR);
        }
    }
}
