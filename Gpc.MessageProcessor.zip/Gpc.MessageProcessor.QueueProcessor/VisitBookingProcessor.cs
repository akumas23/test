﻿using GPC.MessageProcessor.Common;
using GPC.MessageProcessor.Common.DTO;
using GPC.MessageProcessor.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.QueueProcessor
{
    public class VisitBookingProcessor
    {
        MobileBooking mobileBooking;
        Queue queue;
        Guid? BizSessionID;
        ITenantService tenantTransactionService;
        IOutboundMessageQueueService outboundMessageQueueService;

        public VisitBookingProcessor(ITenantService tenantTransactionService, Guid? BizSessionID, IOutboundMessageQueueService outboundMessageQueueService)
        {
            this.tenantTransactionService = tenantTransactionService;
            this.BizSessionID = BizSessionID;
            this.outboundMessageQueueService = outboundMessageQueueService;
        }

        public void ProcessNewVisitBooking(BookingStatusRemarks bookingStatusRemarks, MobileVisit mobileVisit)
        {
            outboundMessageQueueService.LogMessage("Process new visit booking");
            if (bookingStatusRemarks.BookingStatus != BookingStatus.Rejected)
            {
                bookingStatusRemarks = tenantTransactionService.GetNewVisitBookingStatus();
            }

            mobileBooking = tenantTransactionService.CreateMobileVisitBooking(BizSessionID, bookingStatusRemarks);
            mobileVisit.VisitStatus = bookingStatusRemarks.BookingStatus;

            if (bookingStatusRemarks.BookingStatus != BookingStatus.Rejected)
            {
                queue = tenantTransactionService.GetQueueNoByBizSessionID((Guid)BizSessionID);
                queue = tenantTransactionService.CreateQueue(queue, mobileBooking);
                mobileVisit.QueueNumber = queue.QueueNoPrefix + queue.QueueNo;

                mobileBooking.QueueSetupFK = queue.QueueSetupFK;
                tenantTransactionService.UpdateMobileVisitBooking(mobileBooking);
            }
            else
            {
                mobileVisit.QueueNumber = null;
            }
        }

        public void ProcessRequeueVisitBooking(BookingStatusRemarks bookingStatusRemarks, MobileVisit mobileVisit, OutBoundMessageQueue outBoundMessageQueue)
        {
            outboundMessageQueueService.LogMessage("Process requeue visit booking");
            mobileBooking = tenantTransactionService.GetMobileBookingByMobileVisitFK((Guid)outBoundMessageQueue.VisitId);
            mobileBooking.BookingStatusRemarks = bookingStatusRemarks;
           
            mobileBooking.BookingDate = outBoundMessageQueue.BookingDate;
            mobileBooking.BookingRemarks = outBoundMessageQueue.BookingRemarks;
            mobileBooking.MobileVisitDate = outBoundMessageQueue.VisitDate;
            mobileBooking.UpdateByMobilePatientFK = outBoundMessageQueue.PatientProfileId;

            if (bookingStatusRemarks.BookingStatus != BookingStatus.Rejected)
            {
                Queue currentQueue = tenantTransactionService.GetCurrentQueueByMobileBookingFK((Guid)mobileBooking.MobileBookingID);
                queue = tenantTransactionService.GetQueueNoByBizSessionID((Guid)BizSessionID);
                currentQueue.QueueNo = queue.QueueNo;
                currentQueue.QueueNoPrefix = queue.QueueNoPrefix;
                tenantTransactionService.UpdateQueue(currentQueue);

                mobileBooking.QueueSetupFK = queue.QueueSetupFK;
                mobileBooking.BookingStatusRemarks.BookingStatus = BookingStatus.Requeued;
                mobileBooking.BookingStatusRemarks.Remarks = BookingMessage.RequeueByMobileUser;

                tenantTransactionService.UpdateMobileVisitBooking(mobileBooking);

                mobileVisit.QueueNumber = queue.QueueNoPrefix + queue.QueueNo;
            }
            else
            {
                mobileVisit.QueueNumber = null;
                mobileBooking.BookingStatusRemarks.BookingStatus = BookingStatus.Rejected;
                mobileBooking.BookingStatusRemarks.Remarks = bookingStatusRemarks.Remarks;
            }

            mobileVisit.VisitStatus = mobileBooking.BookingStatusRemarks.BookingStatus;
            tenantTransactionService.UpdateMobileVisitBooking(mobileBooking);
        }

        public void ProcessCancelVisitBooking(MobileVisit mobileVisit, OutBoundMessageQueue outBoundMessageQueue)
        {
            outboundMessageQueueService.LogMessage("Process cancel visit booking");
            mobileBooking = tenantTransactionService.GetMobileBookingByMobileVisitFK((Guid)outBoundMessageQueue.VisitId);
            mobileBooking.BookingStatusRemarks.BookingStatus = BookingStatus.Cancelled;
            mobileBooking.BookingStatusRemarks.Remarks = BookingMessage.CancelledByMobileUser;
            mobileBooking.BookingDate = outBoundMessageQueue.BookingDate;
            mobileBooking.BookingRemarks = outBoundMessageQueue.BookingRemarks;
            mobileBooking.MobileVisitDate = outBoundMessageQueue.VisitDate;
            mobileBooking.UpdateByMobilePatientFK = outBoundMessageQueue.PatientProfileId;

            //TODO:delete associated/actualized visit

            tenantTransactionService.UpdateMobileVisitBooking(mobileBooking);

            mobileVisit.VisitStatus = mobileBooking.BookingStatusRemarks.BookingStatus;
        }
    }
}
