﻿using AutoMapper;
using GPC.MessageProcessor.Data;
using GPC.MessageProcessor.Service;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.QueueProcessor
{
    public class ServiceConfiguration
    {


        public void ConfigureServices(out IMobileService outboundMessageQueueService,
                                    out ITenantMappingService tenantMappingService,
                                    out IOutboundMessageQueueService processingLogService,
                                    out ITenantService tenantTransactionService)
        {
            //Create service collection
            var serviceCollection = new ServiceCollection();

            // add services
            serviceCollection.AddTransient<IMobileService, MobileService>();
            serviceCollection.AddTransient<IMobileRepository, MobileRepository>();
            serviceCollection.AddTransient<ITenantMappingService, TenantMappingService>();
            serviceCollection.AddTransient<ITenantMappingRepository, TenantMappingRepository>();
            serviceCollection.AddSingleton<ITenantService, TenantService>();
            serviceCollection.AddSingleton<ITenantRepository, TenantRepository>();
            serviceCollection.AddSingleton<IOutboundMessageQueueRepository, OutboundMessageQueueRepository>();
            serviceCollection.AddSingleton<IOutboundMessageQueueService, OutboundMessageQueueService>();
            serviceCollection.AddTransient<IConnectionFactory, ConnectionFactory>();

            var mapperConfig = new MapperConfiguration(c =>
            {
                c.AddProfile(new MappingProfile());
            });
            var mapper = mapperConfig.CreateMapper();
            serviceCollection.AddSingleton(mapper);

            //Create service provider
            var serviceProvider = serviceCollection.BuildServiceProvider();

            //create service instance
            outboundMessageQueueService = serviceProvider.GetService<IMobileService>();
            tenantMappingService = serviceProvider.GetService<ITenantMappingService>();
            processingLogService = serviceProvider.GetService<IOutboundMessageQueueService>();
            tenantTransactionService = serviceProvider.GetService<ITenantService>();
        }
    }
}
