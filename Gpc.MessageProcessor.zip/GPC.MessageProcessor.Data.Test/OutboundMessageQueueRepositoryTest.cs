using GPC.MessageProcessor.Common;
using GPC.MessageProcessor.Data.InlineQuery;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace GPC.MessageProcessor.Data.Test
{
    [TestClass]
    public class OutboundMessageQueueRepositoryTest
    {
        private Mock<IConnectionFactory> mockConnectionFactory; //Dependency of repo to test
        private IOutboundMessageQueueRepository outboundMessageQueueRepository; //Repo to test
        private SqlConnection sqlConnection;
        private SqlCommand sqlCommand;
        string connectionString = "Server=.;Database=MockDB;User ID=MockUser;Password=MockPassword;Trusted_Connection=False;";

        public OutboundMessageQueueRepositoryTest()
        {
            mockConnectionFactory = new Mock<IConnectionFactory>();
            SetupMockSqlConnection(connectionString);
            mockConnectionFactory.Setup(cf => cf.CreateConnection(ConnectionType.OutboundMessage)).Returns(sqlConnection);

            outboundMessageQueueRepository = new OutboundMessageQueueRepository(mockConnectionFactory.Object);
        }

        [TestMethod]
        public void ConnectionString_For_OutboundMessageQueue()
        {
            var result = outboundMessageQueueRepository.GetConnection();

            Assert.AreEqual(connectionString, result.ConnectionString);
        }

        [TestMethod]
        public void CommandText_For_GetOutboundMessageQueueDetailsByID()
        {
            string commandText = GpcOutBoundMessageComandText.GetOutBoundMessageQueueDetailsByID;
            SetupMockSqlCommand(commandText);
            mockConnectionFactory.Setup(cf => cf.CreateCommand(sqlConnection, GpcOutBoundMessageComandText.GetOutBoundMessageQueueDetailsByID, CommandType.Text)).Returns(sqlCommand);
            mockConnectionFactory.Setup(cf => cf.ExecuteCommandDatatable(sqlCommand)).Returns(MockDataTable(sqlCommand.CommandText));

            var result = outboundMessageQueueRepository.GetOutboundMessageQueueDetailsByID(new Guid("a110a4bb-aede-46ff-a93e-a03aa6768aaa"));

            Assert.AreEqual(1, result.Rows.Count);
        }

        private void SetupMockSqlConnection(string connectionString)
        {
            sqlConnection = new SqlConnection(connectionString);
        }

        private void SetupMockSqlCommand(string commandText)
        {
            sqlCommand = new SqlCommand(commandText, sqlConnection);
        }

        private DataTable MockDataTable(string sqlCommandText)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("DummyColumn");

            if (sqlCommandText == GpcOutBoundMessageComandText.GetOutBoundMessageQueueDetailsByID)
            {
                DataRow dr = dt.NewRow();
                dr[0] = sqlCommandText;
                dt.Rows.Add(dr);
            }

            return dt;
        }
    }
}

