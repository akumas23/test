﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using GPC.MessageProcessor.Common.DTO;
using GPC.MessageProcessor.Data;
using System.Data;

namespace GPC.MessageProcessor.Service
{
    public class TenantMappingService : ITenantMappingService
    {
        private readonly ITenantMappingRepository tenantMappingRepository;
        private readonly IMapper mapper;

        public TenantMappingService(ITenantMappingRepository _tenantMappingRepositor, IMapper _mapper)
        {
            tenantMappingRepository = _tenantMappingRepositor;
            mapper = _mapper;
        }

        public TenantMapping GetTenantMappingByTenantCode(string tenantCode)
        {
            DataTable dt = tenantMappingRepository.GetTenantMappingByTenantCode(tenantCode);
            return this.mapper.Map<TenantMapping>(dt.Rows[0]);
        }
    }
}
