﻿using System;
using System.Collections.Generic;
using System.Text;
using GPC.MessageProcessor.Common.DTO;
using GPC.MessageProcessor.Data;
using System.Data;
using AutoMapper;
using System.Data.SqlClient;
using System.Linq;
using GPC.MessageProcessor.Common;

namespace GPC.MessageProcessor.Service
{
    public class TenantService : ITenantService
    {
        private readonly ITenantRepository tenantTransactionRepository;
        private readonly IMapper mapper;
        private SqlTransaction sqlTransaction;
        private OutBoundMessageQueue outBoundMessageQueue;
        private MobileSetting mobileSetting;
        private PatientProfile patientProfile;

        public TenantService(ITenantRepository _tenantTransactionRepository, IMapper _mapper)
        {
            tenantTransactionRepository = _tenantTransactionRepository;
            mapper = _mapper;
        }

        public void ConfigureTenantTransactionService(TenantMapping tenantMapping, OutBoundMessageQueue outBoundMessageQueue)
        {
            tenantTransactionRepository.SetTenantConnection(tenantMapping);
            this.outBoundMessageQueue = outBoundMessageQueue;
        }

        public OutBoundMessageQueue GetOutBoundMessageQueue()
        {
            return outBoundMessageQueue;
        }

        public Guid? GetTenantActiveSession()
        {
            if (outBoundMessageQueue.VisitId != null)
            {
                DataTable dt = tenantTransactionRepository.GetTenantActiveSession(sqlTransaction);
                if (dt.Rows.Count > 0)
                {
                    return new Guid(dt.Rows[0][0].ToString());
                }
            }
           return null;
        }

        public void GetNewOrExistingPatient()
        {
            DataTable dt = tenantTransactionRepository.GetNewOrExistingPatient(sqlTransaction, outBoundMessageQueue);
            if (dt.Rows.Count > 0)
            {
                this.patientProfile = this.mapper.Map<PatientProfile>(dt.Rows[0]);
            }
            else
            {
                this.patientProfile = this.mapper.Map<PatientProfile>(outBoundMessageQueue);
            }
        }

        public void GetMobileSetting()
        {
            DataTable dt = tenantTransactionRepository.GetMobileSetting(sqlTransaction);
            if (dt.Rows.Count > 0)
            {
                this.mobileSetting = this.mapper.Map<MobileSetting>(dt.Rows[0]);
            }
            else
            {
                throw new Exception("Error getting mobile setting for " + outBoundMessageQueue.TenantCode);
            }
        }

        public Clinic GetClinicDetails()
        {
            DataTable dt = tenantTransactionRepository.GetClinicDetails(sqlTransaction);
            if (dt.Rows.Count > 0)
            {
                return this.mapper.Map<Clinic>(dt.Rows[0]);
            }
            else
            {
                throw new Exception("Error getting clinic details for " + outBoundMessageQueue.TenantCode);
            }
        }

        public BookingStatusRemarks GetNewVisitBookingStatus()
        {
            BookingStatusRemarks bookingStatusRemarks = new BookingStatusRemarks();
            if (mobileSetting.IsAllowVisitBookingEnabled == false)
            {
                bookingStatusRemarks.BookingStatus = BookingStatus.Rejected;
                bookingStatusRemarks.Remarks = BookingMessage.VisitBookingDisabled;
                return bookingStatusRemarks;
            }

            if (mobileSetting.AllowedVisitBooking == VisitBookingAllowedPatientType.ExistingPatientsOnly && patientProfile.PatientType == PatientType.New)
            {
                bookingStatusRemarks.BookingStatus = BookingStatus.Rejected;
                bookingStatusRemarks.Remarks = BookingMessage.VisitBookingForExistingPatientOnly;
                return bookingStatusRemarks;
            }

            if (mobileSetting.AllowedVisitBooking == VisitBookingAllowedPatientType.NewPatientsOnly && patientProfile.PatientType == PatientType.Existing)
            {
                bookingStatusRemarks.BookingStatus = BookingStatus.Rejected;
                bookingStatusRemarks.Remarks = BookingMessage.VisitBookingForNewPatientOnly;
                return bookingStatusRemarks;
            }

            if (mobileSetting.IsVisitMaxCapEnabled)
            {
                int currentBookingCount = 0;
                DataTable dt = tenantTransactionRepository.GetCurrentVisitBookingCount(sqlTransaction);
                if (dt.Rows.Count > 0)
                {
                    currentBookingCount = (int)dt.Rows[0][0];
                    if (currentBookingCount >= mobileSetting.VisitMaxCap)
                    {
                        bookingStatusRemarks.BookingStatus = BookingStatus.Rejected;
                        bookingStatusRemarks.Remarks = BookingMessage.VisitBookingReachedMaxCap;
                        return bookingStatusRemarks;
                    }
                }
                else
                {
                    throw new Exception("Error getting visit booking count");
                }
            }

            bookingStatusRemarks.BookingStatus = BookingStatus.Confirmed;
            return bookingStatusRemarks;
        }

        public MobileBooking GetMobileBookingByMobileVisitFK(Guid MobileVisitFK)
        {
            DataTable dt = tenantTransactionRepository.GetMobileBookingByMobileVisitFK(sqlTransaction, MobileVisitFK);
            if (dt.Rows.Count > 0)
            {
                return this.mapper.Map<MobileBooking>(dt.Rows[0]);
            }
            else
            {
                throw new Exception("Error getting existing mobile visit booking with MobileVisitFK is " + MobileVisitFK.ToString());
            }
        }

        public void UpdateQueue(Queue queue)
        {
            tenantTransactionRepository.UpdateQueue(sqlTransaction, queue);
        }

        public MobileBooking CreateMobileVisitBooking(Guid? bizSessionID, BookingStatusRemarks bookingStatusRemarks)
        {
            MobileBooking mobileBooking = new MobileBooking
            {
                BizSessionFK = bizSessionID,
                PatientName = patientProfile.Name,
                PatientAccountNoTypeFK = patientProfile.PatientAccountNoTypeFK,
                PatientAccountNo = patientProfile.PatientAccountNo,
                GenderFK = patientProfile.GenderFK,
                DOB = patientProfile.DOB,
                Number = patientProfile.Number,
                PatientType = patientProfile.PatientType,
                DesktopPatientProfileFK = patientProfile.PatientProfileID,
                MobileVisitFK = outBoundMessageQueue.VisitId,
                MobileVisitDate = outBoundMessageQueue.VisitDate,
                BookingStatusRemarks = bookingStatusRemarks,
                BookingDate = outBoundMessageQueue.BookingDate,
                BookingRemarks = outBoundMessageQueue.BookingRemarks,
                CreateByMobilePatientFK = outBoundMessageQueue.PatientProfileId,
                UpdateByMobilePatientFK = outBoundMessageQueue.PatientProfileId
            };

            DataTable dt = tenantTransactionRepository.CreateMobileVisitBooking(sqlTransaction, mobileBooking);
            if (dt.Rows.Count > 0)
            {
                mobileBooking.MobileBookingID =  new Guid(dt.Rows[0][0].ToString());
            }

            return mobileBooking;
        }

        public Queue GetQueueNoByBizSessionID(Guid bizSessionID)
        {
            DataTable dt = tenantTransactionRepository.GetQueueNoByBizSessionID(sqlTransaction, bizSessionID);
            var dr = dt.AsEnumerable().Where(x => x.Field<bool>("VC_IsDefault") == true).FirstOrDefault();

            if (dr != null)
            {
                double LastQueueNo = Convert.ToDouble(dr["VC_QueueNo_Numeric"].ToString());
                string QueueNoPrefix = (string) dr["QueueNoPrefix"];
                double RangeStart = Convert.ToDouble(dr["RangeStart"].ToString());
                double NewQueueNo = LastQueueNo + RangeStart;
                Guid? QueueSetupFK = new Guid(dr["VC_QueueCategoryID"].ToString());

                Queue queue = new Queue
                {
                    QueueNoPrefix = QueueNoPrefix,
                    QueueNo = NewQueueNo.ToString().Contains('.') ? NewQueueNo.ToString() : NewQueueNo.ToString() + ".0",
                    CreateByUserFK = DefaultAuditFieldsGuid.User,
                    CreateByLoginFK = DefaultAuditFieldsGuid.Login,
                    CreateByClinicFK = "C1",
                    UpdateByUserFK = DefaultAuditFieldsGuid.User,
                    UpdateByLoginFK = DefaultAuditFieldsGuid.Login,
                    UpdateByClinicFK = "C1",
                    QueueSetupFK = QueueSetupFK
                };

                return queue;
            }

            throw new Exception("Error occur getting last queue no.");
        }

        public Queue GetCurrentQueueByMobileBookingFK(Guid MobileBookingFK)
        {
            DataTable dt = tenantTransactionRepository.GetCurrentQueueByMobileBookingFK(sqlTransaction, MobileBookingFK);
            if (dt.Rows.Count > 0)
            {
                return this.mapper.Map<Queue>(dt.Rows[0]);
            }
            throw new Exception("Error occur getting current queue.");
        }

        public Queue CreateQueue(Queue queue, MobileBooking mobileBooking)
        {
            DataTable dt = tenantTransactionRepository.CreateQueue(sqlTransaction, queue, mobileBooking);
            if (dt.Rows.Count > 0)
            {
                queue.QueueID = new Guid(dt.Rows[0][0].ToString());
            }
            return queue;
        }

        public void UpdateMobileVisitBooking(MobileBooking mobileBooking)
        {
            tenantTransactionRepository.UpdateMobileVisitBooking(sqlTransaction, mobileBooking);
        }

        public void StartTransaction(string transactionName)
        {
            tenantTransactionRepository.GetTenantConnection().Open();
            sqlTransaction = tenantTransactionRepository.GetTenantConnection().BeginTransaction(transactionName);
        }

        public void CommitTransaction()
        {
            sqlTransaction.Commit();
        }

        public void RollBackTransaction()
        {
            sqlTransaction.Rollback();
            tenantTransactionRepository.GetTenantConnection()?.Close();
        }

        public void CleanUpConnection()
        {
            tenantTransactionRepository.GetTenantConnection()?.Dispose();
        }
    }
}
