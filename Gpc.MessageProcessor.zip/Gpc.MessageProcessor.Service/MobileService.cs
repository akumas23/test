﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using AutoMapper;
using GPC.MessageProcessor.Common;
using GPC.MessageProcessor.Common.DTO;
using GPC.MessageProcessor.Data;

namespace GPC.MessageProcessor.Service
{
    public class MobileService : IMobileService
    {
        private readonly IMobileRepository mobileRepository;
        private SqlTransaction sqlTransaction;

        public MobileService(IMobileRepository mobileRepository)
        {
            this.mobileRepository = mobileRepository;
        }

        public void UpdateMobileVisit(MobileVisit mobileVisit)
        {
            mobileRepository.UpdateMobileVisit(sqlTransaction, mobileVisit);
        }

        public void SendVisitNotification(MobileVisit mobileVisit, OutBoundMessageQueue outBoundMessageQueue, Clinic clinic)
        {
            Notification notification = new Notification() { PatientProfileFK = outBoundMessageQueue.PatientProfileId};
            if (mobileVisit.VisitStatus == BookingStatus.Confirmed)
            {
                notification.Message = string.Format(NotificationMessage.ConfirmedVisitBooking, clinic.ClinicName);
            }
            else if (mobileVisit.VisitStatus == BookingStatus.Requeued)
            {
                notification.Message = string.Format(NotificationMessage.RequeuedVisitBooking, clinic.ClinicName, mobileVisit.QueueNumber);
            }
            else if (mobileVisit.VisitStatus == BookingStatus.Cancelled)
            {
                notification.Message = string.Format(NotificationMessage.CancelledVisitBooking, outBoundMessageQueue.VisitDate.Value.ToShortDateString(), clinic.ClinicName);
            }
            else if (mobileVisit.VisitStatus == BookingStatus.Rejected)
            {
                notification.Message = string.Format(NotificationMessage.RejectedVisitBooking, clinic.ClinicName);
            }

            mobileRepository.SendNotification(sqlTransaction, notification);
        }

        public void ErrorProcessingMobileVisit(Guid mobileVisitFk)
        {
            mobileRepository.ErrorProcessingMobileVisit(mobileVisitFk);
        }

        public void CleanUpConnection()
        {
            mobileRepository.GetConnection()?.Dispose();
        }

        public void CommitTransaction()
        {
            sqlTransaction.Commit();
        }

        public void RollBackTransaction()
        {
            sqlTransaction.Rollback();
            mobileRepository.GetConnection()?.Close();
        }

        public void StartTransaction(string transactionName)
        {
            mobileRepository.GetConnection().Open();
            sqlTransaction = mobileRepository.GetConnection().BeginTransaction(transactionName);
        }
    }
}
