﻿using GPC.MessageProcessor.Common.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Service
{
    public interface IOutboundMessageQueueService: IService
    {
        OutBoundMessageQueue GetOutBoundMessageQueueDetailsByID(Guid messageQueueId);
        void UpdateMessageQueueStatus(OutBoundMessageQueue outBoundMessageQueue);
        void LogMessage(string messageLog, string logType = "INFO");
    }
}
