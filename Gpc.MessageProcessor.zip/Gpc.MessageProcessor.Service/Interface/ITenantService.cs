﻿using System;
using System.Collections.Generic;
using System.Text;
using GPC.MessageProcessor.Common.DTO;
namespace GPC.MessageProcessor.Service
{
    public interface ITenantService: IService
    {
        Guid? GetTenantActiveSession();
        void GetNewOrExistingPatient();
        OutBoundMessageQueue GetOutBoundMessageQueue();
        void ConfigureTenantTransactionService(TenantMapping tenantMapping, OutBoundMessageQueue outBoundMessageQueue);
        MobileBooking CreateMobileVisitBooking(Guid? bizSessionID, BookingStatusRemarks bookingStatusRemarks);
        Queue GetQueueNoByBizSessionID(Guid bizSessionID);
        Queue CreateQueue(Queue queue, MobileBooking mobileBooking);
        void GetMobileSetting();
        BookingStatusRemarks GetNewVisitBookingStatus();
        MobileBooking GetMobileBookingByMobileVisitFK(Guid MobileVisitFK);
        Queue GetCurrentQueueByMobileBookingFK(Guid MobileBookingFK);
        void UpdateMobileVisitBooking(MobileBooking mobileBooking);
        void UpdateQueue(Queue queue);
        Clinic GetClinicDetails();
    }
}
