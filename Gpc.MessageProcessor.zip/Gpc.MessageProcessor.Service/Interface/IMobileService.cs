﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using GPC.MessageProcessor.Common.DTO;

namespace GPC.MessageProcessor.Service
{
    public interface IMobileService: IService
    {
        void UpdateMobileVisit(MobileVisit mobileVisit);
        void ErrorProcessingMobileVisit(Guid mobileVisitFk);
        void SendVisitNotification(MobileVisit mobileVisit, OutBoundMessageQueue outBoundMessageQueue, Clinic clinic);
    }
}
