﻿using GPC.MessageProcessor.Common.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Service
{
    public interface ITenantMappingService
    {
        TenantMapping GetTenantMappingByTenantCode(string tenantCode);
    }
}
