﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Service
{
    public interface IService
    {
        void StartTransaction(string transactionName);
        void CommitTransaction();
        void RollBackTransaction();
        void CleanUpConnection();
    }
}
