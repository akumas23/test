﻿using AutoMapper;
using GPC.MessageProcessor.Common;
using GPC.MessageProcessor.Common.DTO;
using GPC.MessageProcessor.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace GPC.MessageProcessor.Service
{
    public class OutboundMessageQueueService: IOutboundMessageQueueService
    {
        private readonly IOutboundMessageQueueRepository outboundMessageQueueRepository;
        private readonly IMapper mapper;
        private SqlTransaction sqlTransaction;
        private OutBoundMessageQueue outboundMessageQueue;

        public OutboundMessageQueueService(IOutboundMessageQueueRepository outboundMessageQueueRepository, IMapper mapper)
        {
            this.outboundMessageQueueRepository = outboundMessageQueueRepository;
            this.mapper = mapper;
        }

        public OutBoundMessageQueue GetOutBoundMessageQueueDetailsByID(Guid messageQueueId)
        {
            DataTable dt = outboundMessageQueueRepository.GetOutboundMessageQueueDetailsByID(messageQueueId);
            if (dt.Rows.Count > 0)
            {
                outboundMessageQueue = this.mapper.Map<OutBoundMessageQueue>(dt.Rows[0]);
                LogMessage("Get Outboundmessage to process");
                return outboundMessageQueue;
            }
            else
            {
                throw new Exception("Error getting Outbound message to process with ID  " + messageQueueId.ToString());
            }
        }

        public void UpdateMessageQueueStatus(OutBoundMessageQueue outBoundMessageQueue)
        {
            outboundMessageQueueRepository.UpdateOutboundMessageQueueStatus(outBoundMessageQueue);
        }

        public void LogMessage(string messageLog, string logType = "INFO")
        {
            MessageProcessingLog message = new MessageProcessingLog(outboundMessageQueue.MessageQueueId, logType, messageLog);
            outboundMessageQueueRepository.LogOutboundMessageProcessing(message);
        }

        public void StartTransaction(string transactionName)
        {
            outboundMessageQueueRepository.GetConnection().Open();
            sqlTransaction = outboundMessageQueueRepository.GetConnection().BeginTransaction(transactionName);
        }

        public void CommitTransaction()
        {
            sqlTransaction.Commit();
        }

        public void RollBackTransaction()
        {
            sqlTransaction.Rollback();
            outboundMessageQueueRepository.GetConnection()?.Close();
        }

        public void CleanUpConnection()
        {
            outboundMessageQueueRepository.GetConnection()?.Dispose();
        }
    }
}
