﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common
{
    public enum ConnectionType
    {
        Mobile,
        DeskTop,
        OutboundMessage
    }

    public static class MessageProcessingLogType
    {
        public static string INFO = "INFO";
        public static string ERROR = "ERROR";
    }

    public static class MessageQueueStatus
    {
        public static string New = "New";
        public static string InProgress = "In-Progress";
        public static string Completed = "Completed";
        public static string Error = "Error";
    }

    public static class DefaultAuditFieldsGuid
    {
        public static Guid Login = new Guid("10000001-0001-0002-0000-000000000000");
        public static Guid User = new Guid("10000001-0001-0001-0000-000000000000");
    }

    public static class PatientType
    {
        public static string New = "New";
        public static string Existing = "Existing";
    }

    public static class TransactionType
    {
        public static string New = "New";
        public static string Requeue = "Requeue";
        public static string ReSced = "Resched";
        public static string Cancel = "Cancel";
    }

    public static class BookingStatus
    {
        public static string Confirmed = "Confirmed";
        public static string Missed = "Missed";
        public static string Requeued = "Requeued";
        public static string Cancelled = "Cancelled";
        public static string Rejected = "Rejected";
    }

    public static class VisitBookingAllowedPatientType
    {
        public static string NewAndExistingPatients = "New and existing patients";
        public static string NewPatientsOnly = "New patients only";
        public static string ExistingPatientsOnly = "Existing patients only";
    }

    public static class BookingMessage
    {
        public static string VisitBookingDisabled = "Visit booking for clinic is disabled.";
        public static string VisitBookingForExistingPatientOnly = "Visit booking is enable for existing patient only.";
        public static string VisitBookingForNewPatientOnly = "Visit booking is enable for new patient only.";
        public static string VisitBookingReachedMaxCap = "Visit booking reached max cap";
        public static string NoActiveBizSession = "No Active BizSession";
        public static string RequeueByMobileUser = "Requeued by mobile user";
        public static string CancelledByMobileUser = "Cancelled by mobile user";
    }

    public static class NotificationMessage
    {
        public static string ConfirmedVisitBooking = "Your visit booking has been confirmed with {0}. Please visit upcoming bookings for more details.";
        public static string CancelledVisitBooking = "Your visit on {0} at {1} has been cancelled. You may reach out to the clinic.";
        public static string RequeuedVisitBooking = "Your new queue number for your visit with {0} is {1}. Please visit upcoming bookings for more details.";
        public static string RejectedVisitBooking = "Your visit booking with {0} was unsuccessful. You may reach out to the clinic.";
    }
}
