﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common.DTO
{
    public class MobileSetting
    {
        public Guid MobileSettingID { get; set; }
        public bool IsMobileSettingsEnabled { get; set; }
        public bool IsAllowVisitBookingEnabled { get; set; }
        public string AllowedVisitBooking { get; set; }
        public bool IsVisitMaxCapEnabled { get; set; }
        public int VisitMaxCap { get; set; }
        public int VisitPushNotification { get; set; }
        public bool IsAutomateMissedQueueEnabled { get; set; }
        public bool IsAllowAppointmentBookingEnabled { get; set; }
        public int AllowedAppointmentBooking { get; set; }
        public bool IsShowServiceStationEnabled { get; set; }
        public bool IsShowClinicianNamesEnabled { get; set; }
        public string AppointmentDuration { get; set; }
        public bool IsAppointmentMaxCapEnabled { get; set; }
        public int AppointmentMaxCap { get; set; }
        public int AppointmentPushNotification { get; set; }
        public bool IsShowNumberOfWaitingPatientsEnabled { get; set; }
        public bool IsShowApproximateWaitingTimeEnabled { get; set; }
        public int ApproximateWaitingTime { get; set; }
    }
}
