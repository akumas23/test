﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common.DTO
{
    public class MobileVisit
    {
        public Guid VisitID { get; set; }
        public string QueueNumber { get; set; }
        public string VisitStatus { get; set; }
    }
}
