﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common.DTO
{
    public class TenantMapping
    {
        public Guid TenantID { get; set; }
        public string TenantCode { get; set; }
        public string SchemaName { get; set; }
        public string DBServer { get; set; }
        public string DBName { get; set; }
        public string HospitalCode { get; set; }
        public string HeCode { get; set; }
    }
}
