﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common.DTO
{
    public class MobileBooking
    {
        public MobileBooking()
        {
            this.BookingStatusRemarks = new BookingStatusRemarks();
        }

        public BookingStatusRemarks BookingStatusRemarks{ get; set; }
        public Guid? MobileBookingID { get; set; }
        public Guid? BizSessionFK { get; set; }
        public string PatientName { get; set; }
        public Guid PatientAccountNoTypeFK { get; set; }
        public string PatientAccountNo { get; set; }
        public Guid GenderFK { get; set; }
        public DateTime DOB { get; set; }
        public string Number { get; set; }
        public string PatientType { get; set; }
        public Guid? MobileVisitFK { get; set; }
        public DateTime? MobileVisitDate { get; set; }
        public Guid? MobileAppointmentFK { get; set; }
        public DateTime? MobileAppointmentDate { get; set; }
        public Guid? MobileAppointmentDoctorFK { get; set; }
        public DateTime BookingDate { get; set; }
        public string BookingRemarks { get; set; }
        public Guid? DesktopVisitFK { get; set; }
        public Guid? DesktopPlannedVisitFK { get; set; }
        public Guid? DesktopPatientProfileFK { get; set; }
        public DateTime CreateDate { get; set; }
        public Guid CreateByMobilePatientFK { get; set; }
        public DateTime? UpdateDate { get; set; }
        public Guid? UpdateByMobilePatientFK { get; set; }
        public Guid? UpdateByLoginFK { get; set; }
        public Guid? UpdateByUserFK { get; set; }
        public string UpdateByClinicFK { get; set; }
        public Guid? QueueSetupFK { get; set; }
        public string QueueNo { get; set; }
    }
}
