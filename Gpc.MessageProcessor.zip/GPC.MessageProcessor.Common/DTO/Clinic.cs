﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common.DTO
{
    public class Clinic
    {
        public string ClinicID { get; set; }
        public string ClinicName { get; set; }
        public string ClinicCode { get; set; }
    }
}
