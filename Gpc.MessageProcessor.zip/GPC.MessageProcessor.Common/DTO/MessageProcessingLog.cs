﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common.DTO
{
    public class MessageProcessingLog
    {
        public Guid MessageQueueFK { get; set; }
        public string Source { get { return "ConsoleApp";} }
        public string LogType { get; set; }
        public string Message { get; set; }
        public DateTime LogDate { get; set; }

        public MessageProcessingLog(Guid messageQueueFK, string logType, string message)
        {
            MessageQueueFK = messageQueueFK;
            LogType = logType;
            Message = message;
            LogDate = DateTime.Now;
        }
    }
}
