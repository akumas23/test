﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common.DTO
{
    public class Queue
    {
        public Guid? QueueID { get; set; }
        public string QueueNo { get; set; }
        public string QueueNoPrefix { get; set; }
        public Guid? VisitFK { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDate { get; set; }
        public Guid CreateByLoginFK { get; set; }
        public Guid CreateByUserFK { get; set; }
        public string CreateByClinicFK { get; set; }
        public DateTime UpdateDate { get; set; }
        public Guid UpdateByLoginFK { get; set; }
        public Guid UpdateByUserFK { get; set; }
        public string UpdateByClinicFK { get; set; }
        public Guid? MobileBookingFK { get; set; }
        public Guid? QueueSetupFK { get; set; }
    }
}
