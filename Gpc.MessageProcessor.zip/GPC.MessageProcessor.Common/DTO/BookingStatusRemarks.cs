﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common.DTO
{
    public class BookingStatusRemarks
    {
        public string BookingStatus { get; set; }
        public string Remarks { get; set; }
    }
}
