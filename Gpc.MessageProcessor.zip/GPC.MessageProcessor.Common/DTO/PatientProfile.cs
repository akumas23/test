﻿using System;
using System.Collections.Generic;
using System.Text;
using GPC.MessageProcessor.Common;

namespace GPC.MessageProcessor.Common.DTO
{
    public class PatientProfile
    {
        public Guid? PatientProfileID { get; set; }
        public Guid PatientAccountNoTypeFK { get; set; }
        public string PatientAccountNo { get; set; }
        public string Name { get; set; }
        public Guid GenderFK { get; set; }
        public DateTime DOB { get; set; }
        public string Number { get; set; }
        public Guid ContactFk { get; set; }
        public Guid? ContactNumberID { get; set; }
        public string PatientType
        {
            get
            {
                if (PatientProfileID == null)
                {
                    return GPC.MessageProcessor.Common.PatientType.New;
                }
                else
                {
                    return GPC.MessageProcessor.Common.PatientType.Existing;
                }
            }
        }
    }
}
