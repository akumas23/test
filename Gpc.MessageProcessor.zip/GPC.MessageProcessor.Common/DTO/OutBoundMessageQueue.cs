﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common.DTO
{
    public class OutBoundMessageQueue
    {
        public Guid MessageQueueId { get; set; }
        public string TenantCode { get; set; }
        public Guid PatientProfileId { get; set; }
        public string PatientName { get; set; }
        public Guid PatientAccountNoTypeFK { get; set; }
        public string PatientAccountNo { get; set; }
        public DateTime DOB { get; set; }
        public Guid GenderFK { get; set; }
        public string Number { get; set; }
        public Guid? VisitId { get; set; }
        public DateTime? VisitDate { get; set; }
        public Guid? AppointmentId { get; set; }
        public DateTime? AppointmentDate { get; set; }
        public Guid? DoctorFK { get; set; }
        public string BookingRemarks { get; set; }
        public DateTime BookingDate { get; set; }
        public string TransactionType { get; set; }
        public DateTime CreateDate { get; set; }
        public Guid CreateByPatientProfileId { get; set; }
        public string ProcessingStatus { get; set; }
        public Guid? GpcPatientProfileId { get; set; }
    }
}
