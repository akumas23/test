﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPC.MessageProcessor.Common.DTO
{
    public class Notification
    {
        public string Message { get; set; }
        public Guid PatientProfileFK { get; set; }
    }
}
