﻿--TODO:This is just a temporary location, move this file in TFS once branch has been created.
CREATE TABLE [Tenant_001].[MobileSetting] (
	MobileSettingID							UNIQUEIDENTIFIER	NOT NULL,
	IsMobileSettingsEnabled					BIT					NULL,
	IsAllowVisitBookingEnabled				BIT					NULL,
	AllowedVisitBooking						NVARCHAR(200)		NULL,
	IsVisitMaxCapEnabled					BIT					NULL,
	VisitMaxCap								INT					NULL,
	VisitPushNotification					INT					NULL,
	IsAutomateMissedQueueEnabled			BIT					NULL,
	IsAllowAppointmentBookingEnabled		BIT					NULL,
	AllowedAppointmentBooking				NVARCHAR(200)		NULL,
	IsShowServiceStationEnabled				BIT					NULL,
	IsShowClinicianNamesEnabled				BIT					NULL,
	AppointmentDuration						NVARCHAR(50)		NULL,
	IsAppointmentMaxCapEnabled				BIT					NULL,
	AppointmentMaxCap						INT					NULL,
	AppointmentPushNotification				INT					NULL,
	IsShowNumberOfWaitingPatientsEnabled	BIT					NULL,
	IsShowApproximateWaitingTimeEnabled		BIT					NULL,
	ApproximateWaitingTime					INT					NULL,
	CreateDate								DATETIME			NOT NULL,
	CreateByLoginFK							UNIQUEIDENTIFIER	NOT NULL,
	CreateByUserFK							UNIQUEIDENTIFIER	NOT NULL,
	CreateByClinicFK						NVARCHAR(10)		NOT NULL,
	UpdateDate								DATETIME			NOT NULL,
	UpdateByLoginFK							UNIQUEIDENTIFIER	NOT NULL,
	UpdateByUserFK							UNIQUEIDENTIFIER	NOT NULL,
	UpdateByClinicFK						NVARCHAR(10)		NOT NULL
 CONSTRAINT [PK_Tenant_001.MobileSetting] PRIMARY KEY CLUSTERED 
(
	MobileSettingID ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO