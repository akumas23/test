﻿--TODO:This is just a temporary location, move this file in TFS once branch has been created.
IF EXISTS ( SELECT  1
            FROM    information_schema.COLUMNS
            WHERE   table_schema = 'Tenant_001'
                    AND TABLE_NAME = 'Queue'
                    AND column_Name = 'MobileBookingFK' )
	BEGIN
		PRINT 'Column already exists'
	END
ELSE
	BEGIN
		ALTER TABLE [Tenant_001].[Queue]
		ADD MobileBookingFK UNIQUEIDENTIFIER NULL 
	END
GO
