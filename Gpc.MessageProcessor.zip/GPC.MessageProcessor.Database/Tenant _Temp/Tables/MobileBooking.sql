﻿--TODO:This is just a temporary location, move this file in TFS once branch has been created.
CREATE TABLE [Tenant_001].[MobileBooking] (
	[MobileBookingID]			UNIQUEIDENTIFIER	NOT NULL,
	[BizSessionFK]				UNIQUEIDENTIFIER	NULL,
	--Patient Info from Mobile
	[PatientName]				NVARCHAR(100)		NOT NULL,
	[PatientAccountNoTypeFK]	UNIQUEIDENTIFIER	NOT NULL,
	[PatientAccountNo]			NVARCHAR(20)		NOT NULL,
	[GenderFK]					UNIQUEIDENTIFIER	NOT NULL,
	[DOB]						DATETIME			NOT NULL,
	[Number]					NVARCHAR(20)		NULL,
	[PatientType]				NVARCHAR(20)		NOT NULL,
	--Visit booking info
	[MobileVisitFK]				UNIQUEIDENTIFIER	NULL,
	[MobileVisitDate]			DATETIME			NULL,
	--Appointment booking info
	[MobileAppointmentFK]		UNIQUEIDENTIFIER	NULL,
	[MobileAppointmentDate]		DATETIME			NULL,
	[MobileAppointmentDoctorFK]	UNIQUEIDENTIFIER	NULL,
	--Shared Info
	[BookingDate]				DATETIME			NOT NULL,
	[BookingStatus]				NVARCHAR(20)		NULL,
	[BookingRemarks]			NVARCHAR(200)		NULL,
	--Reference Info
	[DesktopVisitFK]			UNIQUEIDENTIFIER	NULL,
	[DesktopPlannedVisitFK]		UNIQUEIDENTIFIER	NULL,
	[DesktopPatientProfileFK]	UNIQUEIDENTIFIER	NULL,
	--Audit column
	[CreateDate]				DATETIME			NOT NULL,
	[CreateByMobilePatientFK]	UNIQUEIDENTIFIER	NOT NULL,
	[UpdateDate]				DATETIME			NOT NULL,
	[UpdateByMobilePatientFK]	UNIQUEIDENTIFIER	NOT NULL,
	[UpdateByLoginFK]			UNIQUEIDENTIFIER	NULL,
	[UpdateByUserFK]			UNIQUEIDENTIFIER	NULL,
	[UpdateByClinicFK]			NVARCHAR(10)		NULL,
	[Remarks]					NVARCHAR(500)		NULL,
	[QueueSetupFK]				UNIQUEIDENTIFIER	NULL,
	[RecordVersion]				TIMESTAMP

 CONSTRAINT [PK_Tenant_001.MobileBooking] PRIMARY KEY CLUSTERED 
(
	[MobileBookingID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY] 
) ON [PRIMARY]

GO