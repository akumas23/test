﻿ALTER PROCEDURE [Tenant_001].[GET_Queue_BiggestQueueNo_ByBizSessionID] 
	@BizSessionID	UNIQUEIDENTIFIER
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP 1 *
	FROM (
	SELECT
		TQueue.*
		,CASE ISNUMERIC(QueueNo)
			WHEN 1 THEN CAST(QueueNo AS FLOAT)
			ELSE -0.0
		END AS VC_QueueNo_Numeric
	FROM 
		Tenant_001.[Queue] AS TQueue
		LEFT JOIN Tenant_001.Visit AS TVisit ON (TVisit.VisitID = TQueue.VisitFK)
	WHERE
		TVisit.BizSessionFK = @BizSessionID
		AND
			TVisit.IsDeleted = 0
	UNION
	SELECT
		TQueue.*
		,CASE ISNUMERIC(QueueNo)
			WHEN 1 THEN CAST(QueueNo AS FLOAT)
			ELSE -0.0
		END AS VC_QueueNo_Numeric
	FROM 
		Tenant_001.[Queue] AS TQueue
		LEFT JOIN Tenant_001.MobileBooking AS TVisit ON (TVisit.MobileBookingID = TQueue.MobileBookingFK)
	WHERE
		TVisit.BizSessionFK = @BizSessionID) t
	ORDER BY CAST(t.QueueNo AS Decimal)  DESC
END