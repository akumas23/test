﻿ALTER PROCEDURE [Tenant_001].[GET_Queue_ByBizSessionID] 
	@BizSessionID	UNIQUEIDENTIFIER
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
		TQueue.[QueueID]
		,TQueue.[QueueNo]
		,TQueue.[VisitFK]
		,TQueue.[IsDeleted]
		,TQueue.[CreateDate]
		,TQueue.[CreateByLoginFK]
		,TQueue.[CreateByUserFK]
		,TQueue.[CreateByClinicFK]
		,TQueue.[UpdateDate]
		,TQueue.[UpdateByLoginFK]
		,TQueue.[UpdateByUserFK]
		,TQueue.[UpdateByClinicFK]
		,TQueue.[RecordVersion]
		,TQueue.[QueueNoPrefix]
	FROM 
		Tenant_001.[Queue] AS TQueue
		LEFT JOIN Tenant_001.Visit AS TVisit
			ON (TVisit.VisitID = TQueue.VisitFK)
	WHERE
		TVisit.BizSessionFK = @BizSessionID
		AND
			TVisit.IsDeleted = 0
	UNION
	SELECT 
		TQueue.[QueueID]
		,TQueue.[QueueNo]
		,TQueue.MobileBookingFK
		,TQueue.[IsDeleted]
		,TQueue.[CreateDate]
		,TQueue.[CreateByLoginFK]
		,TQueue.[CreateByUserFK]
		,TQueue.[CreateByClinicFK]
		,TQueue.[UpdateDate]
		,TQueue.[UpdateByLoginFK]
		,TQueue.[UpdateByUserFK]
		,TQueue.[UpdateByClinicFK]
		,TQueue.[RecordVersion]
		,TQueue.[QueueNoPrefix]
	FROM 
		Tenant_001.[Queue] AS TQueue
		LEFT JOIN Tenant_001.MobileBooking AS TVisit
			ON (TVisit.MobileBookingID = TQueue.MobileBookingFK)
	WHERE
		TVisit.BizSessionFK = @BizSessionID
END