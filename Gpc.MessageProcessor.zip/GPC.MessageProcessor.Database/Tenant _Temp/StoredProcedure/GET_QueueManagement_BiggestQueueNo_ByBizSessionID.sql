﻿ALTER PROCEDURE [Tenant_001].[GET_QueueManagement_BiggestQueueNo_ByBizSessionID] 
	@BizSessionID	UNIQUEIDENTIFIER
AS
BEGIN
	SET NOCOUNT ON;
	
	WITH DATA AS 
	(
		SELECT
		QueueID
		,QueueNo
		,VisitFK AS VisitFK
		,IsDeleted
		,CreateDate
		,CreateByLoginFK
		,CreateByUserFK
		,CreateByClinicFK
		,UpdateDate
		,UpdateByLoginFK
		,UpdateByUserFK
		,UpdateByClinicFK
		,RecordVersion
		,QueueNoPrefix
		,VC_QueueNo_Numeric
		,VC_IsDefault
		,VC_QueueCategoryID
		,RANK() OVER(PARTITION BY QueueNoPrefix ORDER BY CAST(QueueNo AS FLOAT) DESC) rn
		,RangeStart
		FROM(SELECT q.QueueID
			,q.QueueNo
			,q.VisitFK AS VisitFK
			,q.IsDeleted
			,q.CreateDate
			,q.CreateByLoginFK
			,q.CreateByUserFK
			,q.CreateByClinicFK
			,q.UpdateDate
			,q.UpdateByLoginFK
			,q.UpdateByUserFK
			,q.UpdateByClinicFK
			,q.RecordVersion
			,q.QueueNoPrefix
			,CASE ISNUMERIC(q.QueueNo) WHEN 1 THEN CAST(q.QueueNo AS FLOAT) ELSE -0.0 END AS 'VC_QueueNo_Numeric'
			,qc.IsDefault AS 'VC_IsDefault'
			,qc.QueueSetupID AS 'VC_QueueCategoryID'
			,qc.RangeStart
			FROM 
				Tenant_001.[Queue] AS q
				LEFT JOIN Tenant_001.Visit AS v ON (v.VisitID = q.VisitFK)
				LEFT JOIN Tenant_001.CTVisitPurpose AS cp ON v.VisitPurposeFK = cp.VisitPurposeID
				LEFT JOIN Tenant_001.CTQueueSetup AS qc ON qc.QueueNoPrefix = q.QueueNoPrefix
			WHERE
				v.BizSessionFK = @BizSessionID
				AND
				v.IsDeleted = 0
				AND
				q.VisitFK IS NOT NULL
				AND
				q.QueueNoPrefix IS NOT NULL
				AND 
				GETDATE() BETWEEN qc.EffectiveStartDate AND qc.EffectiveEndDate
			UNION
			SELECT q.QueueID
			,q.QueueNo
			,q.MobileBookingFK AS VisitFK
			,q.IsDeleted
			,q.CreateDate
			,q.CreateByLoginFK
			,q.CreateByUserFK
			,q.CreateByClinicFK
			,q.UpdateDate
			,q.UpdateByLoginFK
			,q.UpdateByUserFK
			,q.UpdateByClinicFK
			,q.RecordVersion
			,q.QueueNoPrefix
			,CASE ISNUMERIC(q.QueueNo) WHEN 1 THEN CAST(q.QueueNo AS FLOAT) ELSE -0.0 END AS 'VC_QueueNo_Numeric'
			,qc.IsDefault AS 'VC_IsDefault'
			,qc.QueueSetupID AS 'VC_QueueCategoryID'
			,qc.RangeStart
			FROM 
				Tenant_001.[Queue] AS q
				LEFT JOIN Tenant_001.MobileBooking AS m ON (m.MobileBookingID = q.MobileBookingFK)
				LEFT JOIN Tenant_001.CTQueueSetup AS qc ON qc.QueueNoPrefix = q.QueueNoPrefix
			WHERE
				m.BizSessionFK = @BizSessionID
				AND
				q.MobileBookingFK IS NOT NULL
				AND
				q.QueueNoPrefix IS NOT NULL
				AND 
				GETDATE() BETWEEN qc.EffectiveStartDate AND qc.EffectiveEndDate) sub
	)
	SELECT QueueID
		,QueueNo
		,VisitFK
		,IsDeleted
		,CreateDate
		,CreateByLoginFK
		,CreateByUserFK
		,CreateByClinicFK
		,UpdateDate
		,UpdateByLoginFK
		,UpdateByUserFK
		,UpdateByClinicFK
		,RecordVersion
		,QueueNoPrefix
		,VC_QueueNo_Numeric
		,VC_IsDefault
		,VC_QueueCategoryID
		,rn
		,RangeStart 
	FROM DATA WHERE rn = 1
	UNION ALL
	SELECT 
	NULL AS 'QueueID',
	'0.0' AS 'QueueNo',
	NULL AS 'VisitFK',
	0 AS 'IsDeleted',
	qc.CreateDate,
	qc.CreateByLoginFK,
	qc.CreateByUserFK,
	qc.CreateByClinicFK,
	qc.UpdateDate,
	qc.UpdateByLoginFK,
	qc.UpdateByUserFK,
	qc.UpdateByClinicFK,
	qc.RecordVersion,
	qc.QueueNoPrefix,
	1.0 AS 'VC_QueueNo_Numeric',
	qc.IsDefault AS 'VC_IsDefault',
	qc.QueueSetupID AS 'VC_QueueCategoryID',
	1 AS 'rn',
	qc.RangeStart
	FROM Tenant_001.CTQueueSetup AS qc
	WHERE qc.QueueNoPrefix NOT IN (SELECT QueueNoPrefix FROM DATA)
	AND GETDATE() BETWEEN qc.EffectiveStartDate AND qc.EffectiveEndDate
END