﻿CREATE TRIGGER CreateGpcDataSyncRequest
ON [OutBoundMessageQueue]
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
   
	DECLARE @conversation_handle UNIQUEIDENTIFIER
	DECLARE @request_message_body NVARCHAR(max)

	BEGIN TRANSACTION;

	BEGIN DIALOG @conversation_handle
		FROM SERVICE OutboundDataSyncRequestService
		TO SERVICE 'OutboundDataSyncProcessService'
		ON CONTRACT OutboundDataSyncContract
		WITH ENCRYPTION = OFF;

	SET @request_message_body = (SELECT MessageQueueId FROM inserted);

	SEND ON CONVERSATION @conversation_handle
		MESSAGE TYPE OutboundDataSyncRequest (@request_message_body);

	COMMIT TRANSACTION;
END
GO 