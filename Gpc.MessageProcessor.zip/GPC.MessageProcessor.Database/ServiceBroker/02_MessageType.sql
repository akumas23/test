﻿-- Create Message Type for request
CREATE MESSAGE TYPE OutboundDataSyncRequest
VALIDATION = NONE
GO

-- Create Message Type for response
CREATE MESSAGE TYPE OutboundDataSyncResponse
VALIDATION = NONE
GO