﻿CREATE QUEUE [dbo].[OutboundDataSyncProcessQueue] WITH STATUS = ON, RETENTION = OFF,
ACTIVATION (
STATUS = ON,
PROCEDURE_NAME = [dbo].[OutboundDataSyncProcessActivation],
MAX_QUEUE_READERS = 100,
EXECUTE AS OWNER),
POISON_MESSAGE_HANDLING (STATUS = ON) ON [PRIMARY] 
GO

CREATE SERVICE OutboundDataSyncProcessService
ON QUEUE OutboundDataSyncProcessQueue (OutboundDataSyncContract)
GO

--==================================
CREATE QUEUE [dbo].[OutboundDataSyncRequestQueue] WITH STATUS = ON, RETENTION = OFF, 
ACTIVATION (
STATUS = ON ,
PROCEDURE_NAME = [dbo].[OutboundDataSyncRequestActivation],
MAX_QUEUE_READERS = 100,
EXECUTE AS OWNER),
POISON_MESSAGE_HANDLING (STATUS = ON)
GO

CREATE SERVICE OutboundDataSyncRequestService
ON QUEUE OutboundDataSyncRequestQueue (OutboundDataSyncContract)
GO
