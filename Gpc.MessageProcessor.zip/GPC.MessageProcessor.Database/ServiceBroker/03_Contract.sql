﻿CREATE CONTRACT OutboundDataSyncContract
(OutboundDataSyncRequest SENT BY INITIATOR, -->Message to send E.g.: XML, Integer, String, etc..
OutboundDataSyncResponse SENT BY TARGET) -->Message to receive E.g.: XML, Integer, String, etc..
GO
