﻿CREATE TABLE [dbo].[OutBoundMessageQueue](
	[MessageQueueId] [uniqueidentifier] NOT NULL,
	[TenantCode] [nvarchar](200) NOT NULL,
	[PatientProfileId] [uniqueidentifier] NOT NULL,
	[PatientName] [nvarchar](200) NOT NULL,
	[PatientAccountNoTypeFK] [uniqueidentifier] NOT NULL,
	[PatientAccountNo] [nvarchar](20) NOT NULL,
	[GenderFK] [uniqueidentifier] NOT NULL,
	[DOB] [datetime] NOT NULL,
	[Number] [nvarchar](20) NULL,
	[VisitId] [uniqueidentifier] NULL,
	[VisitDate] [datetime] NULL,
	[AppointmentId] [uniqueidentifier] NULL,
	[AppointmentDate] [datetime] NULL,
	[DoctorFK] [uniqueidentifier] NULL,
	[BookingRemarks] [nvarchar](200) NULL,
	[BookingDate] [datetime] NOT NULL,
	[TransactionType] [nvarchar](20) NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[CreateByPatientProfileId] [uniqueidentifier] NOT NULL,
	[ProcessingStatus] [nvarchar](20) NOT NULL,
 CONSTRAINT [PK_OutBoundMessageQueue] PRIMARY KEY CLUSTERED 
(
	[MessageQueueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO