﻿--TODO: This table should be created in mobile database if we will have separate database for Outboundmessage
CREATE TABLE [Notification].[Notification] (
    [NotificationID]            UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
    [Message]					NVARCHAR (500)   NOT NULL,
    [PatientProfileFK]			UNIQUEIDENTIFIER NOT NULL,
    [CreateDate]				DATETIME		 NOT NULL,
	[IsRead]					BIT				 NOT NULL
);