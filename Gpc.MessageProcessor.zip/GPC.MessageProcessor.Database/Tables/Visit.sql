﻿--TODO: This table should be created in mobile database if we will have separate database for Outboundmessage
CREATE TABLE [Visit].[Visit] (
    [VisitId]                   UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
    [RequestDate]               DATETIME         NULL,
    [VisitDate]                 DATETIME         NULL,
    [TenantCode]                NVARCHAR (200)   NULL,
    [Remarks]                   NVARCHAR (200)   NULL,
    [QueueNumber]               NVARCHAR (10)    NULL,
    [VisitStatus]               NVARCHAR (50)    NULL,
    [DoctorFK]                  UNIQUEIDENTIFIER NOT NULL,
    [CreatedByUserFK] UNIQUEIDENTIFIER NOT NULL,
    [CreatedDate]               DATETIME         NULL, 
    [PatientProfileFK]          UNIQUEIDENTIFIER NOT NULL,
    [PatientRelationship] NVARCHAR(50) NULL, 
    [PatientName] NVARCHAR(50) NULL, 
    [PatientIdType] NVARCHAR(50) NULL, 
    [PatientIdNo] NVARCHAR(50) NULL, 
    [PatientDateOfBirth] DATETIME NULL, 
    [PatientGender] NVARCHAR(50) NULL, 
    [PatientMobileNumber] NVARCHAR(50) NULL
);