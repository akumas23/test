﻿CREATE SCHEMA [Notification]
    AUTHORIZATION [dbo];
