﻿CREATE PROCEDURE [dbo].[OutboundDataSyncProcessActivation]
AS
DECLARE @conversation_handle UNIQUEIDENTIFIER;
DECLARE @message_body NVARCHAR(MAX);
DECLARE @message_type_name SYSNAME; 

WHILE(1=1)
BEGIN
	BEGIN TRANSACTION;;

	WAITFOR
	(RECEIVE TOP (1)
	@conversation_handle = CONVERSATION_HANDLE,
	@message_body = CONVERT(NVARCHAR(MAX), message_body),
	@message_type_name = message_type_name
	FROM OutboundDataSyncProcessQueue);

	IF (@@ROWCOUNT = 0)
	BEGIN
		ROLLBACK TRANSACTION;
		BREAK;
	END

	IF @message_type_name = 'OutboundDataSyncRequest'
	BEGIN
		DECLARE @FilePath NVARCHAR(MAX)
		DECLARE @MessageID NVARCHAR(MAX) = @message_body;
		SET @FilePath = (SELECT SettingValue FROM OutboundDataSyncSetting WHERE SettingName = 'ConsoleAppFullPath');

		EXEC INS_MessageProcessingLog @MessageQueueFK = @MessageID, @LogType = 'INFO', @Source = 'SB: Process Activation', @Message = 'Start executing console application using xp_cmdshell'
		
		DECLARE @cmd NVARCHAR(4000)
		SET @cmd = 'cmd.exe /C "' + @FilePath + '" ' + @message_body
		EXEC master..xp_cmdshell @cmd

		EXEC INS_MessageProcessingLog @MessageQueueFK = @MessageID, @LogType = 'INFO', @Source = 'SB: Process Activation', @Message = 'Completed executing console application using xp_cmdshell'
		

		DECLARE @reply_message_body nvarchar(max) = @message_body;

		SEND ON CONVERSATION @conversation_handle
			MESSAGE TYPE OutboundDataSyncResponse (@reply_message_body);
	END
	ELSE IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
	BEGIN
		END CONVERSATION @conversation_handle;
		EXEC INS_MessageProcessingLog @MessageQueueFK = @MessageID, @LogType = 'INFO', @Source = 'SB: Process Activation', @Message = 'End Conversation'
	END
	ELSE IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
	BEGIN
		END CONVERSATION @conversation_handle;
	END

	COMMIT TRANSACTION;
END

--EXEC sys.sp_refreshsqlmodule '[dbo].[OutboundDataSyncProcessActivation]'
