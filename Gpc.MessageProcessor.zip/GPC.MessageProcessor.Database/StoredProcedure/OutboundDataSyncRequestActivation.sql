﻿CREATE PROCEDURE [dbo].[OutboundDataSyncRequestActivation]
AS
DECLARE @conversation_handle UNIQUEIDENTIFIER;
DECLARE @message_body NVARCHAR(MAX);
DECLARE @message_type_name SYSNAME; 

WHILE(1=1)
BEGIN
	BEGIN TRANSACTION;

	WAITFOR
	(RECEIVE TOP (1)
	@conversation_handle = CONVERSATION_HANDLE,
	@message_body = CONVERT(NVARCHAR(MAX), message_body),
	@message_type_name = message_type_name
	from OutboundDataSyncRequestQueue), timeout 5000;

	IF (@@ROWCOUNT = 0)
	BEGIN
		ROLLBACK TRANSACTION;
		BREAK;
	END

	IF @message_type_name = 'OutboundDataSyncResponse'
	BEGIN
		DECLARE @MessageID NVARCHAR(MAX) = @message_body;
		EXEC INS_MessageProcessingLog @MessageQueueFK = @MessageID, @LogType = 'INFO', @Source = 'SB: Process Ends', @Message = 'Completed processing SB queue'
	END
	ELSE IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
	BEGIN
		END CONVERSATION @conversation_handle;
		EXEC INS_MessageProcessingLog @MessageQueueFK = @message_body, @LogType = 'INFO', @Source = 'SB: Process End', @Message = 'End conversation'
	END
	ELSE IF @message_type_name = N'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
	BEGIN
		END CONVERSATION @conversation_handle;
		EXEC INS_MessageProcessingLog @MessageQueueFK = @message_body, @LogType = 'ERROR', @Source = 'SB: Process End', @Message = 'Error'
	END

	COMMIT TRANSACTION;
END