﻿CREATE PROCEDURE [dbo].[INS_MessageProcessingLog]
@MessageQueueFK UNIQUEIDENTIFIER,
@LogType NVARCHAR(50),
@Source NVARCHAR(50),
@Message NVARCHAR(MAX)
AS

INSERT INTO MessageProcessingLog
(MessageQueueFK,LogType,Source,Message,LogDate)
VALUES (@MessageQueueFK, @LogType, @Source, @Message, GETDATE())