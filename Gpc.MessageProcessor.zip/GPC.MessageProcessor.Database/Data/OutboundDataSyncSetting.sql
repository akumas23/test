﻿--TODO: Change local path
IF NOT EXISTS( SELECT 1 FROM [dbo].[OutboundDataSyncSetting] WHERE SettingName = 'ConsoleAppFullPath')
BEGIN
	INSERT INTO [dbo].[OutboundDataSyncSetting](
	SettingID,
	SettingName,SettingValue,Description,
	CreateDate,UpdateDate)
	VALUES (1,
	'ConsoleAppFullPath','C:\Projects\Gpc.MessageProcessor\Gpc.MessageProcessor.QueueProcessor\bin\Debug\netcoreapp2.2\publish\GPC.MessageProcessor.QueueProcessor.exe','Local path of console application to execute',
	GETDATE(),GETDATE())
END