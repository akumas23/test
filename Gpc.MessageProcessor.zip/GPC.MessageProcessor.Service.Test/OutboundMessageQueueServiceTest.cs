using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using GPC.MessageProcessor.Data;
using AutoMapper;
using System;
using System.Data;
using GPC.MessageProcessor.Common.DTO;

namespace GPC.MessageProcessor.Service.Test
{
    [TestClass]
    public class OutboundMessageQueueServiceTest
    {
        private Mock<IOutboundMessageQueueRepository> mockOutboundMessageQueueRepository; //Dependency of Service to test
        private Mock<IMapper> mockMapper; //Dependency of Service to test
        private IOutboundMessageQueueService outboundMessageQueueService; //Actual Service to test

        public OutboundMessageQueueServiceTest()
        {
            mockOutboundMessageQueueRepository = new Mock<IOutboundMessageQueueRepository>();
            mockMapper = new Mock<IMapper>();
            outboundMessageQueueService = new OutboundMessageQueueService(mockOutboundMessageQueueRepository.Object, mockMapper.Object);
        }


        [DataRow("c5caf142-c666-4a10-9196-6d59820b68ae")]
        [DataRow("f366f109-62d9-477c-9aa0-a5f7ee88ed41")]
        [DataRow("bfd4826b-9189-4ae1-85f7-aaf4f4b0b427")]
        [DataTestMethod]
        public void Returned_What_RequestedToGet(string guid)
        {
            Guid guidParam = new Guid(guid);
            this.mockOutboundMessageQueueRepository.Setup(or => or.GetOutboundMessageQueueDetailsByID(guidParam)).Returns(GetDummyOutBoundMessageQueueDataTable(guidParam));
            this.mockMapper.Setup(m => m.Map<OutBoundMessageQueue>(It.IsAny<DataRow>())).Returns(GetDummyOutBoundQueue(guidParam));

            var result = outboundMessageQueueService.GetOutBoundMessageQueueDetailsByID(guidParam);

            Assert.IsNotNull(result);
            Assert.AreEqual(guidParam, result.MessageQueueId);
        }

      
        private OutBoundMessageQueue GetDummyOutBoundQueue(Guid guid)
        {
            DataTable dt = GetDummyOutBoundMessageQueueDataTable(guid);
            OutBoundMessageQueue outBoundMessageQueue = new OutBoundMessageQueue();
            outBoundMessageQueue.MessageQueueId = new Guid(dt.Rows[0]["MessageQueueId"].ToString());
            outBoundMessageQueue.TenantCode = "TenantCode";
            outBoundMessageQueue.DoctorFK = new Guid(dt.Rows[0]["DoctorId"].ToString());
            outBoundMessageQueue.PatientProfileId = new Guid(dt.Rows[0]["DoctorId"].ToString());
            outBoundMessageQueue.GenderFK = new Guid(dt.Rows[0]["DoctorId"].ToString());
            return outBoundMessageQueue;
        }

        private DataTable GetDummyOutBoundMessageQueueDataTable(Guid guid)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("MessageQueueId");
            dt.Columns.Add("TenantCode");
            dt.Columns.Add("DoctorId");
            dt.Columns.Add("PatientProfileId");
            dt.Columns.Add("RelationhipId");
            dt.Columns.Add("Name");
            dt.Columns.Add("IdTypeId");
            dt.Columns.Add("IdNo");
            dt.Columns.Add("DateOfBirth");
            dt.Columns.Add("GenderId");
            dt.Columns.Add("AppointmentId");
            dt.Columns.Add("AppointmentDate");
            dt.Columns.Add("AppointmentStatus");
            dt.Columns.Add("VisitId");
            dt.Columns.Add("VisitRequestDate");
            dt.Columns.Add("Remarks");
            dt.Columns.Add("TransactionType");
            dt.Columns.Add("CreateByPatientProfileId");
            dt.Columns.Add("CreateDate");
            dt.Columns.Add("MessageQueueStatus");

            DataRow dr = dt.NewRow();
            dr["MessageQueueId"] = guid;
            dr["TenantCode"] = "GPCTenant_001";
            dr["DoctorId"] = new Guid("f366f109-62d9-477c-9aa0-a5f7ee88ed41");
            dr["PatientProfileId"] = new Guid("c23adc02-caa1-4ef4-9e99-d736114a2019");
            dr["RelationhipId"] = null;
            dr["Name"] = "CHAS and SFL user 266";
            dr["IdTypeId"] = new Guid("2baa0b53-7044-40b1-857c-be06e1672b03");
            dr["IdNo"] = "S0687483E";
            dr["DateOfBirth"] = new DateTime(1965,1,1);
            dr["GenderId"] = new Guid("00000000-0000-0000-0000-000000000002");
            dr["AppointmentId"] = null;
            dr["AppointmentDate"] = null;
            dr["AppointmentStatus"] = null;
            dr["VisitId"] = new Guid("c5caf142-c666-4a10-9196-6d59820b68ae");
            dr["VisitRequestDate"] = DateTime.Now;
            dr["Remarks"] = "";
            dr["TransactionType"] = "New";
            dr["CreateByPatientProfileId"] = new Guid("21795d6c-e7a2-486f-b7fe-1df3e67cd98c");
            dr["CreateDate"] = DateTime.Now;
            dr["MessageQueueStatus"] = "New";
            dt.Rows.Add(dr);
            return dt;
        }
    }
}
