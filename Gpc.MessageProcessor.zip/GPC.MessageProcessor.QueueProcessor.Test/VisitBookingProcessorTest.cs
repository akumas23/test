using System;
using GPC.MessageProcessor.Service;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using GPC.MessageProcessor.QueueProcessor;
using GPC.MessageProcessor.Common.DTO;
using GPC.MessageProcessor.Common;

namespace GPC.MessageProcessor.QueueProcessor.Test
{
    [TestClass]
    public class VisitBookingProcessorTest
    {
        private Mock<ITenantService> mockTenantTransactionService;
        private Mock<IOutboundMessageQueueService> mockOutboundMessageQueueService;

        private Guid? BizSessionID;
        private BookingStatusRemarks bookingStatusRemarks;
        private MobileVisit mobileVisit;

        private Queue mockGetQueueNoByBizSessionID;
        private MobileBooking mockCreateMobileVisitBooking;
        private Queue mockCreateQueue;

        private VisitBookingProcessor visitBookingProcessor; //Class to test

        public VisitBookingProcessorTest()
        {
            BizSessionID = Guid.NewGuid();
            mockTenantTransactionService = new Mock<ITenantService>();
            mockOutboundMessageQueueService = new Mock<IOutboundMessageQueueService>();

            visitBookingProcessor = new VisitBookingProcessor(mockTenantTransactionService.Object,BizSessionID,mockOutboundMessageQueueService.Object);

            mockGetQueueNoByBizSessionID = MockQueue(new Guid("7E908EB1-A8FF-471B-B8A8-3BEF67F36940"));
            mockCreateMobileVisitBooking = MockMobileBooking(new Guid("C116A2B3-20AF-4911-AE8B-05DE8D238357"));
            mockCreateQueue = MockQueue(new Guid("A0CB29F3-0C2D-4B57-B269-238B0465810D"));
        }

        [TestMethod]
        public void NewVisitBooking_RejectedBooking_NoQueueNumber()
        {
            bookingStatusRemarks = MockBookingStatusRemarks(BookingStatus.Rejected);
            mobileVisit = MockMobileVisit();

            visitBookingProcessor.ProcessNewVisitBooking(bookingStatusRemarks, mobileVisit);

            Assert.IsNull(mobileVisit.QueueNumber);
        }

        [TestMethod]
        public void NewVisitBooking_ConfirmedBooking_WithCorrectQueueNumber()
        {
            bookingStatusRemarks = MockBookingStatusRemarks(BookingStatus.Confirmed);
            mobileVisit = MockMobileVisit();

            mockTenantTransactionService.Setup(ts => ts.GetNewVisitBookingStatus()).Returns(bookingStatusRemarks);
            mockTenantTransactionService.Setup(ts => ts.CreateMobileVisitBooking(BizSessionID, bookingStatusRemarks)).Returns(mockCreateMobileVisitBooking);
            mockTenantTransactionService.Setup(ts => ts.GetQueueNoByBizSessionID((Guid)BizSessionID)).Returns(mockGetQueueNoByBizSessionID);
            mockTenantTransactionService.Setup(ts => ts.CreateQueue(mockGetQueueNoByBizSessionID, mockCreateMobileVisitBooking)).Returns(mockCreateQueue);

            visitBookingProcessor.ProcessNewVisitBooking(bookingStatusRemarks, mobileVisit);

            Assert.IsNotNull(mobileVisit.QueueNumber);
            Assert.AreEqual(mobileVisit.QueueNumber,mockCreateQueue.QueueNoPrefix + mockCreateQueue.QueueNo);
            Assert.AreEqual(mockCreateMobileVisitBooking.QueueSetupFK, mockCreateQueue.QueueSetupFK);
        }


        public BookingStatusRemarks MockBookingStatusRemarks(string bookingStatus)
        {
            BookingStatusRemarks bookingStatusRemarks = new BookingStatusRemarks();
            bookingStatusRemarks.BookingStatus = bookingStatus;
            bookingStatusRemarks.Remarks = "Remarks";

            return bookingStatusRemarks;
        }

        public MobileVisit MockMobileVisit()
        {
            MobileVisit mobileVisit = new MobileVisit();
            return mobileVisit;
        }

        public MobileBooking MockMobileBooking(Guid? mobileBookingGuid)
        {
            MobileBooking mobileBooking = new MobileBooking();
            mobileBooking.MobileBookingID = mobileBookingGuid;
            return mobileBooking;
        }

        public Queue MockQueue(Guid? queueId)
        {
            Queue queue = new Queue();
            queue.QueueNoPrefix = "A";
            queue.QueueNo = "99";

            if (queueId != null)
            {
                queue.QueueID = (Guid)queueId;
            }

            queue.QueueSetupFK = Guid.NewGuid();

            return queue;
        }
    }
}
